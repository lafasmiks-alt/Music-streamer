import asyncio
import json
import os
import random
import re
import sys
import time
import unicodedata
from collections import deque
from functools import lru_cache
from pathlib import Path
from typing import Optional

from highrise import BaseBot
from highrise.models import AnchorPosition, Item, Position, User

import data
from music_player import MusicPlayer, Track
from radio import AudioBroadcaster

ADMIN_USERNAME = "the_alperenn"
DEFAULT_BOT_EMOTE = "dance-floss"

WORD_BANK = (
    {"word": "elma", "hints": ("Ağaçta yetişir ve yenir.", "Yuvarlak bir meyvedir.", "Kırmızı veya yeşil olabilir.")},
    {"word": "uçak", "hints": ("Gökyüzünde hareket eder.", "İnsanları uzak yerlere götürür.", "Kanatları vardır.")},
    {"word": "kitap", "hints": ("Sayfaları vardır ve okunur.", "Bilgi veya hikâye içerebilir.", "Kütüphanede bulunabilir.")},
    {"word": "güneş", "hints": ("Gökyüzünde görülür.", "Dünyayı aydınlatır ve ısıtır.", "Sabah doğar, akşam batar.")},
    {"word": "telefon", "hints": ("İletişim kurmaya yarar.", "Arama ve mesajlaşma için kullanılır.", "Cebe sığabilecek bir model olabilir.")},
    {"word": "kahve", "hints": ("Sıcak içilen bir içecektir.", "Sabahları sık tercih edilir.", "Çekirdekleri öğütülerek hazırlanır.")},
    {"word": "deniz", "hints": ("Geniş bir su alanıdır.", "Suyu genellikle tuzludur.", "Kıyısında tatil yapılabilir.")},
    {"word": "kedi", "hints": ("Evde beslenebilir.", "Miyavlar ve bıyıkları vardır.", "Sessizce yürüyebilir.")},
    {"word": "köpek", "hints": ("Sadık bir evcil hayvandır.", "Havlayabilir.", "Bazıları insanlara eşlik eder.")},
    {"word": "bisiklet", "hints": ("İki tekerleği vardır.", "Pedal çevrilerek kullanılır.", "Yakıt gerektirmez.")},
    {"word": "şemsiye", "hints": ("Yağmurda kullanılır.", "Açılıp kapanabilir.", "Elde taşınır.")},
    {"word": "kalem", "hints": ("Yazı yazmak için kullanılır.", "Çantada taşınabilir.", "Bazı türleri silinebilir.")},
    {"word": "masa", "hints": ("Üzerine eşya konur.", "Yemek yerken kullanılabilir.", "Ayakları vardır.")},
    {"word": "ayna", "hints": ("Karşısına geçince görüntünü gösterir.", "Camdan yapılabilir.", "Duvara asılabilir.")},
    {"word": "çikolata", "hints": ("Tatlı bir yiyecektir.", "Kakao ile yapılır.", "Sütlü veya bitter olabilir.")},
    {"word": "araba", "hints": ("Yollarda kullanılır.", "Tekerlekleri vardır.", "İnsanları ve eşyaları taşıyabilir.")},
    {"word": "ay", "hints": ("Gece gökyüzünde görülür.", "Dünyanın çevresinde dolaşır.", "Kendi ışığını üretmez.")},
    {"word": "yıldız", "hints": ("Gece gökyüzünde görülür.", "Uzakta parlayan bir gök cismidir.", "Güneş de bu gruba girer.")},
    {"word": "çiçek", "hints": ("Bitkinin renkli bir bölümü olabilir.", "Kokusu güzel olabilir.", "Bahçelerde yetişir.")},
    {"word": "doktor", "hints": ("İnsanları muayene eder.", "Hastalıkların tedavisiyle ilgilenir.", "Hastanede çalışabilir.")},
    {"word": "okul", "hints": ("Ders öğrenmek için gidilir.", "Öğrenciler ve öğretmenler bulunur.", "Sınıfları vardır.")},
    {"word": "saat", "hints": ("Zamanı gösterir.", "Kolda veya duvarda bulunabilir.", "Akrep ve yelkovanı olabilir.")},
    {"word": "kapı", "hints": ("Bir odaya giriş çıkışı sağlar.", "Açılıp kapanır.", "Kilitlenebilir.")},
    {"word": "bulut", "hints": ("Gökyüzünde görülür.", "Beyaz veya gri olabilir.", "Yağmur getirebilir.")},
    {"word": "gitar", "hints": ("Bir müzik aletidir.", "Telleri vardır.", "Parmaklarla çalınabilir.")},
)

WORD_BANK_EN = (
    {"word": "apple", "hints": ("It grows on a tree.", "It is a round fruit.", "It can be red or green.")},
    {"word": "plane", "hints": ("It moves through the sky.", "It takes people to far places.", "It has wings.")},
    {"word": "book", "hints": ("It has pages and can be read.", "It can contain knowledge or stories.", "You can find it in a library.")},
    {"word": "sun", "hints": ("You can see it in the sky.", "It lights and warms the world.", "It rises in the morning.")},
    {"word": "phone", "hints": ("It helps people communicate.", "It can be used for calls and messages.", "A small one can fit in your pocket.")},
    {"word": "coffee", "hints": ("It is usually served hot.", "Many people drink it in the morning.", "It is made from roasted beans.")},
    {"word": "sea", "hints": ("It is a large area of water.", "Its water is usually salty.", "People can have holidays near it.")},
    {"word": "cat", "hints": ("It can be kept at home.", "It meows and has whiskers.", "It can walk very quietly.")},
    {"word": "dog", "hints": ("It is a loyal pet.", "It can bark.", "It can keep people company.")},
    {"word": "bicycle", "hints": ("It has two wheels.", "It is moved by pedals.", "It does not need fuel.")},
    {"word": "umbrella", "hints": ("It is used in the rain.", "It can open and close.", "It is carried by hand.")},
    {"word": "pencil", "hints": ("It is used for writing.", "It can be carried in a school bag.", "Some types can be erased.")},
    {"word": "table", "hints": ("Things can be placed on it.", "People can eat at it.", "It has legs.")},
    {"word": "mirror", "hints": ("It shows your reflection.", "It can be made of glass.", "It can hang on a wall.")},
    {"word": "chocolate", "hints": ("It is a sweet food.", "It is made with cocoa.", "It can be milk or dark.")},
    {"word": "car", "hints": ("It is used on roads.", "It has wheels.", "It can carry people and things.")},
    {"word": "moon", "hints": ("You can see it at night.", "It travels around Earth.", "It does not make its own light.")},
    {"word": "star", "hints": ("You can see it at night.", "It is a distant object that shines.", "The sun belongs to this group.")},
    {"word": "flower", "hints": ("It can be a colorful part of a plant.", "It can have a nice smell.", "It can grow in a garden.")},
    {"word": "doctor", "hints": ("They examine people.", "They help treat illnesses.", "They can work in a hospital.")},
    {"word": "school", "hints": ("People go there to learn.", "Students and teachers are there.", "It has classrooms.")},
    {"word": "clock", "hints": ("It shows the time.", "It can be on a wall or a wrist.", "It can have hands.")},
    {"word": "door", "hints": ("It lets people enter and leave a room.", "It opens and closes.", "It can be locked.")},
    {"word": "cloud", "hints": ("You can see it in the sky.", "It can be white or gray.", "It can bring rain.")},
    {"word": "guitar", "hints": ("It is a musical instrument.", "It has strings.", "It can be played with fingers.")},
)

AUTO_RADIO_TR = (
    "Tarkan Şımarık",
    "Tarkan Kuzu Kuzu",
    "Sezen Aksu Gülümse",
    "Sezen Aksu Hadi Bakalım",
    "Mustafa Sandal Aya Benzer",
    "Barış Manço Gülpembe",
    "Kenan Doğulu Çakkıdı",
    "Gülşen Bangır Bangır",
    "Hadise Düm Tek Tek",
    "Simge Aşkın Olayım",
    "Mabel Matiz Antidepresan",
    "Edis Martılar",
    "Mert Demir Ateşe Düştüm",
    "Zeynep Bastık Uslanmıyor Bu",
    "Yalın Ki Sen",
    "Teoman Paramparça",
    "Emir Can İğrek Nalan",
    "Sertab Erener Rengârenk",
    "Buray Sen Sevda Mısın",
    "Ajda Pekkan Yakar Geçerim",
)

AUTO_RADIO_EN = (
    "The Weeknd Blinding Lights",
    "Dua Lipa Levitating",
    "Ed Sheeran Shape of You",
    "Taylor Swift Cruel Summer",
    "Bruno Mars Just the Way You Are",
    "Adele Rolling in the Deep",
    "Rihanna Diamonds",
    "Queen Don't Stop Me Now",
    "Michael Jackson Billie Jean",
    "Coldplay Viva La Vida",
    "Imagine Dragons Believer",
    "Maroon 5 Sugar",
    "Avicii Wake Me Up",
    "Justin Bieber Sorry",
    "Billie Eilish Bad Guy",
    "Miley Cyrus Flowers",
    "Sia Chandelier",
    "Lady Gaga Bad Romance",
    "The Weeknd Save Your Tears",
    "OneRepublic Counting Stars",
)

MESSAGE_COLORS = (
    "#00ccff",
    "#ffbf00",
    "#ff6699",
    "#cc44ff",
    "#00ff88",
    "#ffaa00",
)

# Cooldown before the same user can be teleported again via a `!<point>`
# command, to avoid hammering the Highrise API if someone spams it.
_TELE_COOLDOWN_SECONDS = 2.0


@lru_cache(maxsize=2)
def _load_word_list(language: str) -> tuple[str, ...]:
    filename = "words-en.json" if language == "eng" else "words-tr.json"
    word_path = Path(__file__).resolve().parent / "wordlists" / filename
    try:
        with word_path.open("r", encoding="utf-8") as file:
            words = json.load(file)
    except (OSError, json.JSONDecodeError) as exc:
        raise RuntimeError(f"Kelime listesi yüklenemedi: {word_path}") from exc

    if not isinstance(words, list) or len(words) != 20_000:
        raise RuntimeError(f"{filename} tam 20.000 kelime içermeli.")
    if any(not isinstance(word, str) or not word for word in words):
        raise RuntimeError(f"{filename} geçersiz kelime içeriyor.")
    return tuple(words)


@lru_cache(maxsize=2)
def _load_word_hints(language: str) -> dict[str, str]:
    wordlist_dir = Path(__file__).resolve().parent / "wordlists"
    language_code = "en" if language == "eng" else "tr"
    filename = f"hints-{language_code}.json"
    shard_paths = sorted(wordlist_dir.glob(f"hints-{language_code}-*.json"))
    hint_paths = shard_paths or [wordlist_dir / filename]
    hints: dict[str, str] = {}

    for hint_path in hint_paths:
        try:
            with hint_path.open("r", encoding="utf-8") as file:
                chunk = json.load(file)
        except (OSError, json.JSONDecodeError) as exc:
            raise RuntimeError(f"Kelime ipuçları yüklenemedi: {hint_path}") from exc

        if not isinstance(chunk, dict) or any(
            not isinstance(word, str) or not isinstance(hint, str) or not hint.strip()
            for word, hint in chunk.items()
        ):
            raise RuntimeError(f"{hint_path.name} geçersiz ipucu verisi içeriyor.")
        if hints.keys() & chunk.keys():
            raise RuntimeError(f"{hint_path.name} önceki ipucu parçasıyla yinelenen kelimeler içeriyor.")
        hints.update(chunk)

    return hints


def _is_admin(user: User) -> bool:
    return user.username.lower() == ADMIN_USERNAME.lower()


def _is_customer_owner(user: User) -> bool:
    owner = data.get_bot_owner()
    return bool(owner and owner["user_id"] == user.id)


def _is_role_manager(user: User) -> bool:
    return _is_admin(user) or _is_customer_owner(user)


def _is_privileged(user: User) -> bool:
    return _is_admin(user) or _is_customer_owner(user) or data.is_host(user.id)


def _is_unlimited(user: User) -> bool:
    return _is_admin(user) or _is_customer_owner(user) or data.is_host(user.id) or data.is_vip(user.id)


class MusicBot(BaseBot):
    def __init__(self, broadcaster: AudioBroadcaster, room_id: Optional[str] = None):
        self.player = MusicPlayer()
        self.broadcaster = broadcaster
        self._room_id = room_id
        self.queue: deque[Track] = deque()
        self.current_track: Optional[Track] = None
        self.is_playing: bool = False
        self._auto_radio_active: bool = False
        self._auto_radio_recent: deque[str] = deque(maxlen=8)
        self._play_task: Optional[asyncio.Task] = None
        self._emote_task: Optional[asyncio.Task] = None
        self._loop_task: Optional[asyncio.Task] = None
        self._word_task: Optional[asyncio.Task] = None
        self._loop_text: Optional[str] = None
        self._word_current: Optional[dict] = None
        self._word_last: Optional[str] = None
        self._current_emote: Optional[str] = None
        self._bot_id: Optional[str] = None
        self._user_positions: dict[str, Position] = {}
        self._tele_cooldowns: dict[str, float] = {}
        self._message_color_index = 0
        self.language = data.get_language()

    def _t(self, turkish: str, english: str) -> str:
        return english if self.language == "eng" else turkish

    def _colorize_message(self, message: str) -> str:
        if "<#" in message:
            return message
        color = MESSAGE_COLORS[self._message_color_index % len(MESSAGE_COLORS)]
        self._message_color_index += 1
        return f"<{color}>{message}"

    async def _chat(self, message: str) -> None:
        await self.highrise.chat(self._colorize_message(message))

    async def _whisper(self, user_id: str, message: str) -> None:
        await self.highrise.send_whisper(user_id, self._colorize_message(message))

    async def on_start(self, session_metadata) -> None:
        print(f"[Bot] Bağlandı. Bot ID: {session_metadata.user_id}")
        self._bot_id = session_metadata.user_id
        self.language = data.get_language()
        if self._room_id:
            data.save_room_id(self._room_id)
            data.save_last_good_room_id(self._room_id)
        saved_pos = data.get_position()
        if saved_pos:
            try:
                await self.highrise.walk_to(
                    Position(saved_pos["x"], saved_pos["y"], saved_pos["z"], saved_pos.get("facing", "FrontRight"))
                )
                print(f"[Bot] Kaydedilen konuma gidildi: {saved_pos}")
            except Exception as e:
                print(f"[Bot] Konuma gidemedi: {e}")

        saved_outfit = data.get_outfit()
        if saved_outfit:
            try:
                items = [Item(id=it["id"], type=it["type"], amount=it.get("amount", 1), account_bound=it.get("account_bound", False), active_palette=it.get("active_palette", None)) for it in saved_outfit]
                await self.highrise.set_outfit(items)
                print("[Bot] Kaydedilen kıyafet giyildi.")
            except Exception as e:
                print(f"[Bot] Kıyafet giydirme hatası: {e}")

        saved_loop_text = data.get_loop_text()
        if saved_loop_text:
            if self._loop_task and not self._loop_task.done():
                self._loop_task.cancel()
            self._loop_text = saved_loop_text
            self._loop_task = asyncio.create_task(self._loop_message_task())
            print("[Bot] Kaydedilen loop mesajı yeniden başlatıldı.")

        await self.highrise.chat(self._t(
            "<#00ccff>\U0001f3b5 <#ffffff>Müzik botu hazır! İstek yokken otomatik radyo çalar. "
            "<#ffbf00>-p şarkı adı <#ffffff>yazarak istek ekle.",
            "<#00ccff>\U0001f3b5 <#ffffff>Music bot ready! Auto radio plays when there are no requests. "
            "Use <#ffbf00>-p song name <#ffffff>to add a track.",
        ))
        if self._emote_task and not self._emote_task.done():
            self._emote_task.cancel()
        self._current_emote = DEFAULT_BOT_EMOTE
        self._emote_task = asyncio.create_task(self._emote_loop(DEFAULT_BOT_EMOTE))
        if data.is_word_game_enabled():
            self._start_word_game()
        else:
            self._stop_word_game()
        if not self._play_task or self._play_task.done():
            self._play_task = asyncio.create_task(self._playback_loop())

    async def on_chat(self, user: User, message: str) -> None:
        try:
            msg = message.strip()
            print(f"[Chat] {user.username}: {msg!r}")

            if msg.startswith("-p ") or msg.lower() == "-p":
                rest = msg[3:].strip()
                await self._cmd_play(user, rest, "")
                return

            if msg.lower() == "/fav":
                await self._cmd_fav(user)
                return

            if not msg.startswith("!"):
                if await self._check_word_guess(user, msg):
                    return
                plain = msg.lower()
                if plain and plain in data.get_teleports():
                    await self._teleport_user_to(user, plain)
                return

            await self._dispatch_command(user, msg, allow_teleport=True)
        except Exception as e:
            print(f"[Bot] Komut hatası [{message}]: {e}")

    async def on_whisper(self, user: User, message: str) -> None:
        """Handle the bot's private admin/host commands."""
        try:
            msg = message.strip()
            print(f"[Whisper] {user.username}: {msg!r}")
            command_text = msg[1:].strip() if msg.startswith("!") else msg
            command = command_text.split(" ", 1)[0].lower()
            if command in {"setbot", "botemote"}:
                command_msg = msg if msg.startswith("!") else f"!{msg}"
                await self._dispatch_command(user, command_msg, allow_teleport=False)
        except Exception as e:
            print(f"[Bot] Fısıltı komutu hatası [{message}]: {e}")

    async def _dispatch_command(self, user: User, msg: str, allow_teleport: bool) -> None:
        parts = msg[1:].strip().split(" ", 2)
        cmd = parts[0].lower()
        arg1 = parts[1].strip() if len(parts) > 1 else ""
        arg2 = parts[2].strip() if len(parts) > 2 else ""

        handlers = {
            "play": self._cmd_play,
            "skip": self._cmd_skip,
            "stop": self._cmd_stop,
            "queue": self._cmd_queue,
            "np": self._cmd_np,
            "nowplaying": self._cmd_np,
            "coin": self._cmd_coin,
            "top": self._cmd_top,
            "puan": self._cmd_top,
            "daily": self._cmd_daily,
            "give": self._cmd_give,
            "ban": self._cmd_ban,
            "unban": self._cmd_unban,
            "addhost": self._cmd_addhost,
            "removehost": self._cmd_removehost,
            "addvip": self._cmd_addvip,
            "removevip": self._cmd_removevip,
            "m": self._cmd_set_owner,
            "room": self._cmd_room,
            "restart": self._cmd_restart,
            "setbot": self._cmd_setbot,
            "o": self._cmd_outfit,
            "del": self._cmd_del,
            "up": self._cmd_up,
            "url": self._cmd_url,
            "help": self._cmd_help,
            "copy": self._cmd_copy,
            "botemote": self._cmd_botemote,
            "loop": self._cmd_loop,
            "welcome": self._cmd_welcome,
            "goodbye": self._cmd_goodbye,
            "kelime": self._cmd_kelime,
            "kelimedur": self._cmd_kelime_dur,
            "deltele": self._cmd_deltele,
            "teleports": self._cmd_teleports,
            "lan": self._cmd_language,
        }

        handler = handlers.get(cmd)
        if handler:
            await handler(user, arg1, arg2)
        elif allow_teleport:
            await self._cmd_teleport_point(user, cmd)

    def _stop_word_game(self) -> None:
        if self._word_task and not self._word_task.done():
            self._word_task.cancel()
        self._word_task = None
        self._word_current = None

    def _start_word_game(self) -> None:
        self._stop_word_game()
        self._word_task = asyncio.create_task(self._word_game_loop())

    def _choose_word(self) -> dict:
        words = _load_word_list(self.language)
        choices = [word for word in words if word != self._word_last]
        word = random.choice(choices or list(words))
        self._word_last = word

        curated_bank = WORD_BANK_EN if self.language == "eng" else WORD_BANK
        curated_hints = {
            entry["word"].casefold(): " ".join(entry["hints"])
            for entry in curated_bank
        }
        dictionary_hints = _load_word_hints(self.language)
        hint_key = word.casefold() if self.language == "eng" else word
        hint = curated_hints.get(word.casefold()) or dictionary_hints.get(hint_key)
        hint = self._expand_word_hint(word, hint)
        return {"word": word, "hint": hint}

    def _expand_word_hint(self, word: str, hint: Optional[str]) -> str:
        english = self.language == "eng"
        first_letter = word[0].upper()
        last_letter = word[-1].upper()
        if hint:
            source = hint.strip()
            if len(source.split()) < 4:
                source = self._t(
                    f"Bu kelimenin kısa açıklaması: “{source}”",
                    f"A short dictionary clue is: “{source}”",
                )
            sentences = [
                sentence.strip()
                for sentence in re.split(r"(?<=[.!?])\s+", source)
                if sentence.strip()
            ]
            sentences = [
                sentence if sentence.endswith((".", "?", "!")) else f"{sentence}."
                for sentence in sentences[:4]
            ]
        else:
            sentences = [
                self._t(
                    "Bu kelime için sözlük açıklaması bulunamadı.",
                    "A dictionary definition is not available for this word.",
                )
            ]

        extra_clues = [
            self._t(
                f"Kelime {len(word)} harften oluşuyor.",
                f"The word has {len(word)} letters.",
            ),
            self._t(
                f"İlk harfi {first_letter}, son harfi {last_letter}.",
                f"It starts with {first_letter} and ends with {last_letter}.",
            ),
        ]
        for clue in extra_clues:
            if len(sentences) >= 3:
                break
            sentences.append(clue)
        return " ".join(sentences)

    async def _send_word_hint(self, current: dict) -> None:
        label = self._t("İpucu", "Hint")
        await self._chat(f"💡 {label}: {current['hint']}")

    def _normalize_word_guess(self, value: str) -> str:
        normalized = unicodedata.normalize("NFKC", value).strip()
        if self.language != "eng":
            normalized = normalized.replace("I", "ı").replace("İ", "i")
        normalized = normalized.casefold().strip(" \t\r\n.,!?;:…\"'()[]{}")
        return " ".join(normalized.split())

    async def _word_game_loop(self) -> None:
        try:
            while True:
                current = self._choose_word()
                self._word_current = current
                await self._send_word_hint(current)

                deadline = time.monotonic() + 35
                while self._word_current is current and time.monotonic() < deadline:
                    await asyncio.sleep(min(0.5, max(0.05, deadline - time.monotonic())))

                if self._word_current is current:
                    # Reveal the answer at timeout, then give the room a moment
                    # before starting the next round.
                    self._word_current = None
                    await self._chat(self._t(
                        f"💡 Süre doldu! Cevap: {current['word']}",
                        f"💡 Time's up! The answer was: {current['word']}",
                    ))
                    await asyncio.sleep(3)
                else:
                    await asyncio.sleep(3)
        except asyncio.CancelledError:
            pass
        except Exception as e:
            print(f"[Bot] Kelime oyunu hatası: {e}")

    async def _check_word_guess(self, user: User, message: str) -> bool:
        current = self._word_current
        if not current:
            return False

        guess = self._normalize_word_guess(message)
        answer = self._normalize_word_guess(current["word"])
        if guess != answer:
            return False

        # Claim the round before sending a reply so concurrent chat events cannot
        # award the same word to multiple users.
        self._word_current = None
        await self._chat(self._t(
            f"💡 Tebrikler @{user.username}, doğru kelimeyi ilk sen bildin!",
            f"💡 Congratulations @{user.username}, you guessed the word first!",
        ))
        return True

    async def _cmd_set_owner(self, user: User, arg1: str, arg2: str) -> None:
        if not _is_admin(user):
            await self._chat(self._t(
                "Bu komut sadece botun ana adminine özel.",
                "This command is reserved for the bot's primary admin.",
            ))
            return

        target_name = (arg1 + (" " + arg2 if arg2 else "")).strip()
        if not target_name:
            owner = data.get_bot_owner()
            if owner:
                await self._chat(self._t(
                    f"Bot sahibi: @{owner['username']}. Değiştirmek için !m @kullanıcı yaz.",
                    f"Bot owner: @{owner['username']}. Change with !m @username.",
                ))
            else:
                await self._chat(self._t(
                    "Kullanım: !m @kullanıcı",
                    "Usage: !m @username",
                ))
            return

        if target_name.casefold() in {"off", "kapat", "disable"}:
            data.set_bot_owner(None, None)
            await self._chat(self._t(
                "Bot sahibi kaldırıldı; ana admin yedek yetkisini koruyor.",
                "Bot owner removed; the primary admin keeps backup access.",
            ))
            return

        target_name = target_name.strip().strip("() ").lstrip("@").strip()
        target_user = await self._find_room_user(target_name)
        if not target_user:
            await self._chat(self._t(
                f"@{target_name} odada bulunamadı. Sahip atamak için odada olması gerekiyor.",
                f"@{target_name} was not found in the room. They must be in the room to be assigned.",
            ))
            return
        if _is_admin(target_user):
            await self._chat(self._t(
                "Ana admin zaten yedek admin olarak kayıtlı.",
                "The primary admin is already the backup admin.",
            ))
            return

        data.set_bot_owner(target_user.id, target_user.username)
        await self._chat(self._t(
            f"@{target_user.username} botun yeni sahibi oldu. Host/VIP ve oda ayarlarını yönetebilir; !room kullanamaz.",
            f"@{target_user.username} is now the bot owner. They can manage hosts, VIPs, and room settings, but cannot use !room.",
        ))

    async def _cmd_kelime(self, user: User, arg1: str, arg2: str) -> None:
        if not _is_privileged(user):
            await self._chat(self._t(
                "💡 Bu komut sadece admin ve hostlara özel.",
                "💡 This command is only for admins and hosts.",
            ))
            return

        data.set_word_game_enabled(True)
        self._start_word_game()
        await self._chat(self._t(
            "💡 Kelime oyunu başlatıldı. Kelimeyi tahmin etmek için cevabı odaya yaz.",
            "💡 Word game started. Type the answer in the room to guess.",
        ))

    async def _cmd_kelime_dur(self, user: User, arg1: str, arg2: str) -> None:
        if not _is_privileged(user):
            await self._chat(self._t(
                "💡 Bu komut sadece admin ve hostlara özel.",
                "💡 This command is only for admins and hosts.",
            ))
            return

        data.set_word_game_enabled(False)
        self._stop_word_game()
        await self._chat(self._t(
            "💡 Kelime oyunu durduruldu.",
            "💡 Word game stopped.",
        ))

    async def _cmd_language(self, user: User, arg1: str, arg2: str) -> None:
        if not _is_role_manager(user):
            await self.highrise.chat(self._t(
                "\u274c Bu komut sadece admine özel.",
                "\u274c This command is for the admin only.",
            ))
            return

        requested = arg1.lower().strip()
        if requested == "en":
            requested = "eng"
        if requested not in {"tr", "eng"}:
            await self.highrise.chat(self._t(
                "\u274c Kullanım: !lan tr veya !lan eng",
                "\u274c Usage: !lan tr or !lan eng",
            ))
            return

        data.set_language(requested)
        self.language = requested
        if data.is_word_game_enabled():
            self._start_word_game()
        await self.highrise.chat(self._t(
            "\U0001f310 Dil Türkçe olarak ayarlandı.",
            "\U0001f310 Language set to English.",
        ))

    async def on_user_join(self, user: User, position) -> None:
        if isinstance(position, Position):
            self._user_positions[user.id] = position
        if user.id == self._bot_id:
            return

        welcome_text = data.get_welcome_text()
        if welcome_text:
            message = welcome_text.replace("{user}", f"@{user.username}")
            try:
                await self._chat(message)
            except Exception as e:
                print(f"[Bot] Hoş geldin mesajı gönderilemedi: {e}")

    async def on_user_leave(self, user: User) -> None:
        self._user_positions.pop(user.id, None)
        self._tele_cooldowns.pop(user.id, None)
        if user.id == self._bot_id:
            return

        goodbye_text = data.get_goodbye_text()
        if goodbye_text:
            message = goodbye_text.replace("{user}", f"@{user.username}")
            try:
                await self._chat(message)
            except Exception as e:
                print(f"[Bot] Ayrılma mesajı gönderilemedi: {e}")

    async def on_user_move(self, user: User, destination) -> None:
        if not isinstance(destination, Position):
            return
        self._user_positions[user.id] = destination

    async def _teleport_user_to(self, user: User, name: str) -> None:
        dest = data.get_teleports().get(name)
        if not dest:
            return
        last = self._tele_cooldowns.get(user.id, 0.0)
        now = time.monotonic()
        if now - last < _TELE_COOLDOWN_SECONDS:
            return
        self._tele_cooldowns[user.id] = now
        try:
            await self.highrise.teleport(
                user.id,
                Position(dest["x"], dest["y"], dest["z"], dest.get("facing", "FrontRight")),
            )
        except Exception as e:
            print(f"[Bot] Işınlama hatası ({user.username} -> {name}): {e}")

    async def _cmd_teleport_point(self, user: User, name: str) -> None:
        """Fallback for any `!<name>` that isn't a known command.

        Admin-only: saves their current spot under `name` (so `!k1` defines
        the point). Teleporting to it afterward happens via plain `k1` in
        chat, handled in on_chat, not through this `!` path.
        """
        if not _is_role_manager(user):
            return
        if name in data.get_teleports():
            return

        pos = self._user_positions.get(user.id)
        if not pos:
            await self.highrise.chat(self._t(
                "\u274c Konumun alınamadı, biraz hareket edip tekrar dene.",
                "\u274c Your position could not be found. Move a little and try again.",
            ))
            return

        data.save_teleport(name, {"x": pos.x, "y": pos.y, "z": pos.z, "facing": pos.facing})
        await self.highrise.chat(self._t(
            f"<#00ff88>\u2705 <#ffffff>Işınlanma noktası kaydedildi: <#ffbf00>{name}\n"
            f"<#888888>Artık herkes sohbete '{name}' yazarak buraya ışınlanabilir.",
            f"<#00ff88>\u2705 <#ffffff>Teleport point saved: <#ffbf00>{name}\n"
            f"<#888888>Anyone can now type '{name}' in chat to teleport here.",
        ))

    async def _cmd_play(self, user: User, arg1: str, arg2: str) -> None:
        query = (arg1 + " " + arg2).strip()
        if not query:
            await self.highrise.chat(self._t(
                "\u274c Kullanım: !play <şarkı adı veya bağlantı>",
                "\u274c Usage: !play <song name or link>",
            ))
            return

        if data.is_banned(user.id):
            await self.highrise.chat(self._t(
                f"<#ff4444>\U0001f6ab {user.username}<#ffffff>, müzik çalma yetkin kaldırılmış.",
                f"<#ff4444>\U0001f6ab {user.username}<#ffffff>, you are not allowed to play music.",
            ))
            return

        is_unlimited = _is_unlimited(user)
        is_vip_user = data.is_vip(user.id)

        if not is_unlimited:
            coins = data.get_coins(user.id, user.username)
            if coins < 100:
                await self.highrise.chat(self._t(
                    f"<#ff4444>\U0001f4b8 {user.username}<#ffffff>, yeterli coinin yok! <#ffbf00>Gerekli: 100 coin <#ffffff>| <#ffaa00>Bakiye: {coins} <#ffffff>— !daily ile coin kazan.",
                    f"<#ff4444>\U0001f4b8 {user.username}<#ffffff>, you need more coins! <#ffbf00>Required: 100 coins <#ffffff>| <#ffaa00>Balance: {coins} <#ffffff>— earn coins with !daily.",
                ))
                return

        await self._whisper(user.id, self._t(
            f"{query} adlı şarkınız aranıyor.\U0001f50d",
            f"Searching for your song: {query}.\U0001f50d",
        ))
        track = await self.player.search(query)

        if not track:
            await self._whisper(user.id, self._t(
                "\u274c Şarkı bulunamadı.",
                "\u274c Song not found.",
            ))
            return

        track.requested_by = user.username
        track.requested_by_id = user.id

        if not is_unlimited:
            data.add_coins(user.id, user.username, -100)
            track.coins_charged = 100

        title_short = track.title[:50] + ("..." if len(track.title) > 50 else "")
        queue_msg = self._t(
            f"<#00ff88>\u2705 Kuyruğa eklendi!\n<#ffbf00>{title_short}\n<#888888>@{user.username} \u2022 Bot: @the_alperenn",
            f"<#00ff88>\u2705 Added to the queue!\n<#ffbf00>{title_short}\n<#888888>@{user.username} \u2022 Bot: @the_alperenn",
        )

        if is_vip_user or _is_privileged(user):
            self.queue.appendleft(track)
        else:
            self.queue.append(track)

        if self._auto_radio_active and self._play_task and not self._play_task.done():
            await self._next_track()
        elif not self._play_task or self._play_task.done():
            self._auto_radio_active = False
            self.is_playing = False
            await self._start_playback()

        await self.highrise.chat(queue_msg)

    async def _cmd_skip(self, user: User, arg1: str, arg2: str) -> None:
        if not _is_privileged(user):
            await self.highrise.chat(self._t(
                "<#ff4444>\u274c <#ffffff>Sadece admin/host kullanabilir.",
                "<#ff4444>\u274c <#ffffff>Only the admin/host can use this.",
            ))
            return
        task_alive = self._play_task and not self._play_task.done()
        if not self.is_playing and not task_alive:
            await self.highrise.chat(self._t(
                "<#ff4444>\u274c <#ffffff>Şu an çalan şarkı yok.",
                "<#ff4444>\u274c <#ffffff>There is no song playing right now.",
            ))
            return
        await self.highrise.chat(self._t(
            f"<#ffbf00>\u23ed {user.username} <#ffffff>şarkıyı geçti.",
            f"<#ffbf00>\u23ed {user.username} <#ffffff>skipped the song.",
        ))
        await self._next_track()

    async def _cmd_stop(self, user: User, arg1: str, arg2: str) -> None:
        if not _is_privileged(user):
            await self.highrise.chat(self._t(
                f"<#ff4444>\u274c {user.username}<#ffffff>, bu komut sadece admin ve hostlara özel.",
                f"<#ff4444>\u274c {user.username}<#ffffff>, this command is only for admins and hosts.",
            ))
            return
        self.queue.clear()
        self.current_track = None
        self.is_playing = False
        self._auto_radio_active = False
        if self._play_task and not self._play_task.done():
            self._play_task.cancel()
        await self.highrise.chat(self._t(
            "<#ff4444>\u23f9 <#ffffff>Müzik ve otomatik radyo durduruldu; kuyruk temizlendi.",
            "<#ff4444>\u23f9 <#ffffff>Music and auto radio stopped; the queue was cleared.",
        ))

    async def _cmd_queue(self, user: User, arg1: str, arg2: str) -> None:
        if not self.current_track and not self.queue:
            await self.highrise.chat(self._t(
                "<#888888>\U0001f4ed Kuyruk boş.",
                "<#888888>\U0001f4ed The queue is empty.",
            ))
            return
        lines = []
        if self.current_track:
            lines.append(self._t(
                f"<#ffbf00>\u25b6 Şu an: <#ffffff>{self.current_track.title} <#888888>[{self.current_track.duration_str}] <#aaaaaa>— {self.current_track.requested_by}",
                f"<#ffbf00>\u25b6 Now playing: <#ffffff>{self.current_track.title} <#888888>[{self.current_track.duration_str}] <#aaaaaa>— {self.current_track.requested_by}",
            ))
        for i, t in enumerate(list(self.queue)[:5], 1):
            lines.append(f"<#00ccff>{i}. <#ffffff>{t.title} <#888888>[{t.duration_str}]")
        if len(self.queue) > 5:
            lines.append(self._t(
                f"<#888888>... ve {len(self.queue) - 5} şarkı daha",
                f"<#888888>... and {len(self.queue) - 5} more songs",
            ))
        await self.highrise.chat("\n".join(lines))

    async def _cmd_np(self, user: User, arg1: str, arg2: str) -> None:
        if not self.current_track:
            if self.is_playing or (self._play_task and not self._play_task.done()):
                await self.highrise.chat(self._t(
                    "<#888888>\u23f3 Sıradaki şarkı yükleniyor...",
                    "<#888888>\u23f3 Loading the next song...",
                ))
            else:
                await self.highrise.chat(self._t(
                    "<#ff4444>\u274c <#ffffff>Şu an çalan şarkı yok.",
                    "<#ff4444>\u274c <#ffffff>There is no song playing right now.",
                ))
            return
        await self.highrise.chat(self._t(
            f"<#ffbf00>\U0001f3b5 Şu an çalıyor: <#ffffff>{self.current_track.title}\n"
            f"<#ffbf00>\u23f1 Süre: <#ffffff>{self.current_track.duration_str}\n"
            f"<#ffbf00>\U0001f464 İsteyen: <#ffffff>{self.current_track.requested_by or 'Bilinmiyor'}",
            f"<#ffbf00>\U0001f3b5 Now playing: <#ffffff>{self.current_track.title}\n"
            f"<#ffbf00>\u23f1 Duration: <#ffffff>{self.current_track.duration_str}\n"
            f"<#ffbf00>\U0001f464 Requested by: <#ffffff>{self.current_track.requested_by or 'Unknown'}",
        ))

    async def _cmd_coin(self, user: User, arg1: str, arg2: str) -> None:
        if _is_unlimited(user):
            await self.highrise.chat(self._t(
                f"<#ffaa00>\U0001f4b0 {user.username}<#ffbf00>, sınırsız coinin var! \U0001f31f",
                f"<#ffaa00>\U0001f4b0 {user.username}<#ffbf00>, you have unlimited coins! \U0001f31f",
            ))
            return
        coins = data.get_coins(user.id, user.username)
        await self.highrise.chat(self._t(
            f"<#ffaa00>\U0001f4b0 {user.username}<#ffffff>, bakiyeniz: <#ffbf00>{coins} coin",
            f"<#ffaa00>\U0001f4b0 {user.username}<#ffffff>, your balance is: <#ffbf00>{coins} coins",
        ))

    async def _cmd_top(self, user: User, arg1: str, arg2: str) -> None:
        entries = data.get_top_coins(10)
        if not entries:
            await self._chat(self._t(
                "🏆 Henüz coin sıralaması oluşmadı.",
                "🏆 The coin leaderboard is empty yet.",
            ))
            return

        lines = [
            self._t(
                "<#ffbf00>🏆 TOP 10 COIN SIRALAMASI",
                "<#ffbf00>🏆 TOP 10 COIN LEADERBOARD",
            )
        ]
        rank_colors = ("#ffbf00", "#ff6699", "#cc44ff", "#00ccff", "#00ff88")
        for rank, entry in enumerate(entries, 1):
            color = rank_colors[(rank - 1) % len(rank_colors)]
            lines.append(
                f"<{color}>{rank}. <#ffffff>@{entry['username']} "
                f"<#ffaa00>{entry['coins']} coin"
            )

        await self.highrise.chat("\n".join(lines))

    async def _cmd_daily(self, user: User, arg1: str, arg2: str) -> None:
        if _is_unlimited(user):
            await self.highrise.chat(self._t(
                f"<#ffaa00>\U0001f4b0 {user.username}<#ffffff>, zaten sınırsız coinin var!",
                f"<#ffaa00>\U0001f4b0 {user.username}<#ffffff>, you already have unlimited coins!",
            ))
            return
        success, new_balance = data.claim_daily(user.id, user.username)
        if success:
            await self.highrise.chat(self._t(
                f"<#00ff88>\U0001f381 {user.username}<#ffffff>, günlük <#ffbf00>100 coin <#ffffff>alındı! Yeni bakiye: <#ffaa00>{new_balance} coin",
                f"<#00ff88>\U0001f381 {user.username}<#ffffff>, you received your daily <#ffbf00>100 coins<#ffffff>! New balance: <#ffaa00>{new_balance} coins",
            ))
        else:
            await self.highrise.chat(self._t(
                f"<#ff4444>\u23f3 {user.username}<#ffffff>, bugün zaten aldın! Yarın tekrar dene.",
                f"<#ff4444>\u23f3 {user.username}<#ffffff>, you already claimed it today! Try again tomorrow.",
            ))

    async def _cmd_give(self, user: User, arg1: str, arg2: str) -> None:
        if not arg1 or not arg2:
            await self.highrise.chat(self._t(
                "<#ff4444>\u274c <#ffffff>Kullanım: !give @kullanıcı <miktar>",
                "<#ff4444>\u274c <#ffffff>Usage: !give @user <amount>",
            ))
            return
        try:
            amount = int(arg2)
            if amount <= 0:
                raise ValueError
        except ValueError:
            await self.highrise.chat(self._t(
                "<#ff4444>\u274c <#ffffff>Geçerli bir miktar gir.",
                "<#ff4444>\u274c <#ffffff>Enter a valid amount.",
            ))
            return

        if not _is_unlimited(user):
            sender_coins = data.get_coins(user.id, user.username)
            if sender_coins < amount:
                await self.highrise.chat(self._t(
                    f"<#ff4444>\U0001f4b8 {user.username}<#ffffff>, yeterli coinin yok! Bakiye: <#ffaa00>{sender_coins}",
                    f"<#ff4444>\U0001f4b8 {user.username}<#ffffff>, you do not have enough coins! Balance: <#ffaa00>{sender_coins}",
                ))
                return

        target_user = await self._find_room_user(arg1)
        if not target_user:
            await self.highrise.chat(self._t(
                f"<#ff4444>\u274c <#ffffff>'{arg1}' odada bulunamadı.",
                f"<#ff4444>\u274c <#ffffff>'{arg1}' was not found in the room.",
            ))
            return

        if not _is_unlimited(user):
            data.add_coins(user.id, user.username, -amount)

        new_balance = data.add_coins(target_user.id, target_user.username, amount)
        await self.highrise.chat(self._t(
            f"<#ffaa00>\U0001f4b8 {user.username} <#ffffff>\u2192 <#ffaa00>{target_user.username}<#ffffff>: <#ffbf00>{amount} coin <#ffffff>gönderildi! <#888888>({target_user.username} bakiye: {new_balance})",
            f"<#ffaa00>\U0001f4b8 {user.username} <#ffffff>\u2192 <#ffaa00>{target_user.username}<#ffffff>: <#ffbf00>{amount} coins <#ffffff>sent! <#888888>({target_user.username}'s balance: {new_balance})",
        ))

    async def _find_room_user(self, arg: str) -> Optional[User]:
        target_username = arg.lstrip("@").lower()
        try:
            resp = await self.highrise.get_room_users()
            room_users = resp.content if hasattr(resp, "content") else []
        except Exception:
            room_users = []
        for u, _ in room_users:
            if u.username.lower() == target_username:
                return u
        return None

    async def _cmd_ban(self, user: User, arg1: str, arg2: str) -> None:
        if not _is_privileged(user):
            await self.highrise.chat(self._t(
                "<#ff4444>\u274c <#ffffff>Sadece admin/host kullanabilir.",
                "<#ff4444>\u274c <#ffffff>Only the admin/host can use this.",
            ))
            return
        if not arg1:
            await self.highrise.chat(self._t(
                "<#ff4444>\u274c <#ffffff>Kullanım: !ban @kullanıcı",
                "<#ff4444>\u274c <#ffffff>Usage: !ban @user",
            ))
            return
        target_user = await self._find_room_user(arg1)
        if not target_user:
            await self.highrise.chat(self._t(
                f"<#ff4444>\u274c <#ffffff>'{arg1}' odada bulunamadı.",
                f"<#ff4444>\u274c <#ffffff>'{arg1}' was not found in the room.",
            ))
            return
        data.ban_user(target_user.id, target_user.username)
        await self.highrise.chat(self._t(
            f"<#ff4444>\U0001f6ab {target_user.username} <#ffffff>müzik çalmaktan yasaklandı.",
            f"<#ff4444>\U0001f6ab {target_user.username} <#ffffff>is banned from playing music.",
        ))

    async def _cmd_unban(self, user: User, arg1: str, arg2: str) -> None:
        if not _is_privileged(user):
            await self.highrise.chat(self._t(
                "<#ff4444>\u274c <#ffffff>Sadece admin/host kullanabilir.",
                "<#ff4444>\u274c <#ffffff>Only the admin/host can use this.",
            ))
            return
        if not arg1:
            await self.highrise.chat(self._t(
                "<#ff4444>\u274c <#ffffff>Kullanım: !unban @kullanıcı",
                "<#ff4444>\u274c <#ffffff>Usage: !unban @user",
            ))
            return
        target_user = await self._find_room_user(arg1)
        if not target_user:
            await self.highrise.chat(self._t(
                f"<#ff4444>\u274c <#ffffff>'{arg1}' odada bulunamadı.",
                f"<#ff4444>\u274c <#ffffff>'{arg1}' was not found in the room.",
            ))
            return
        removed = data.unban_user(target_user.id)
        if removed:
            await self.highrise.chat(self._t(
                f"<#00ff88>\u2705 {target_user.username} <#ffffff>yasağı kaldırıldı.",
                f"<#00ff88>\u2705 {target_user.username}'s ban was removed.",
            ))
        else:
            await self.highrise.chat(self._t(
                f"<#ff4444>\u274c {target_user.username} <#ffffff>zaten yasaklı değil.",
                f"<#ff4444>\u274c {target_user.username} <#ffffff>is not banned.",
            ))

    async def _cmd_addhost(self, user: User, arg1: str, arg2: str) -> None:
        if not _is_role_manager(user):
            await self.highrise.chat(self._t(
                "<#ff4444>\u274c <#ffffff>Bu komut sadece admine özel.",
                "<#ff4444>\u274c <#ffffff>This command is for the admin only.",
            ))
            return
        if not arg1:
            await self.highrise.chat(self._t(
                "<#ff4444>\u274c <#ffffff>Kullanım: !addhost @kullanıcı",
                "<#ff4444>\u274c <#ffffff>Usage: !addhost @user",
            ))
            return
        target_user = await self._find_room_user(arg1)
        if not target_user:
            await self.highrise.chat(self._t(
                f"<#ff4444>\u274c <#ffffff>'{arg1}' odada bulunamadı.",
                f"<#ff4444>\u274c <#ffffff>'{arg1}' was not found in the room.",
            ))
            return
        data.add_host(target_user.id, target_user.username)
        await self.highrise.chat(self._t(
            f"<#ffbf00>\U0001f451 {target_user.username} <#ffffff>host yapıldı! <#ffaa00>Artık sınırsız coini var.",
            f"<#ffbf00>\U0001f451 {target_user.username} <#ffffff>is now a host! <#ffaa00>They now have unlimited coins.",
        ))

    async def _cmd_removehost(self, user: User, arg1: str, arg2: str) -> None:
        if not _is_role_manager(user):
            await self.highrise.chat(self._t(
                "<#ff4444>\u274c <#ffffff>Bu komut sadece admine özel.",
                "<#ff4444>\u274c <#ffffff>This command is for the admin only.",
            ))
            return
        if not arg1:
            await self.highrise.chat(self._t(
                "<#ff4444>\u274c <#ffffff>Kullanım: !removehost @kullanıcı",
                "<#ff4444>\u274c <#ffffff>Usage: !removehost @user",
            ))
            return
        target_user = await self._find_room_user(arg1)
        if not target_user:
            await self.highrise.chat(self._t(
                f"<#ff4444>\u274c <#ffffff>'{arg1}' odada bulunamadı.",
                f"<#ff4444>\u274c <#ffffff>'{arg1}' was not found in the room.",
            ))
            return
        removed = data.remove_host(target_user.id)
        if removed:
            await self.highrise.chat(self._t(
                f"<#00ff88>\u2705 {target_user.username} <#ffffff>hostluktan çıkarıldı.",
                f"<#00ff88>\u2705 {target_user.username} <#ffffff>was removed as a host.",
            ))
        else:
            await self.highrise.chat(self._t(
                f"<#ff4444>\u274c {target_user.username} <#ffffff>zaten host değil.",
                f"<#ff4444>\u274c {target_user.username} <#ffffff>is not a host.",
            ))

    async def _cmd_addvip(self, user: User, arg1: str, arg2: str) -> None:
        if not _is_privileged(user):
            await self.highrise.chat(self._t(
                "<#ff4444>\u274c <#ffffff>Bu komut sadece admin ve hostlara özel.",
                "<#ff4444>\u274c <#ffffff>This command is only for admins and hosts.",
            ))
            return
        if not arg1:
            await self.highrise.chat(self._t(
                "<#ff4444>\u274c <#ffffff>Kullanım: !addvip @kullanıcı",
                "<#ff4444>\u274c <#ffffff>Usage: !addvip @user",
            ))
            return
        target_user = await self._find_room_user(arg1)
        if not target_user:
            await self.highrise.chat(self._t(
                f"<#ff4444>\u274c <#ffffff>'{arg1}' odada bulunamadı.",
                f"<#ff4444>\u274c <#ffffff>'{arg1}' was not found in the room.",
            ))
            return
        data.add_vip(target_user.id, target_user.username)
        await self.highrise.chat(self._t(
            f"<#cc44ff>\u2b50 {target_user.username} <#ffffff>VIP yapıldı! <#ffbf00>Sınırsız coin <#ffffff>+ <#cc44ff>öncelikli kuyruk!",
            f"<#cc44ff>\u2b50 {target_user.username} <#ffffff>is now VIP! <#ffbf00>Unlimited coins <#ffffff>+ <#cc44ff>priority queue!",
        ))

    async def _cmd_removevip(self, user: User, arg1: str, arg2: str) -> None:
        if not _is_privileged(user):
            await self.highrise.chat(self._t(
                "<#ff4444>\u274c <#ffffff>Bu komut sadece admin ve hostlara özel.",
                "<#ff4444>\u274c <#ffffff>This command is only for admins and hosts.",
            ))
            return
        if not arg1:
            await self.highrise.chat(self._t(
                "<#ff4444>\u274c <#ffffff>Kullanım: !removevip @kullanıcı",
                "<#ff4444>\u274c <#ffffff>Usage: !removevip @user",
            ))
            return
        target_user = await self._find_room_user(arg1)
        if not target_user:
            await self.highrise.chat(self._t(
                f"<#ff4444>\u274c <#ffffff>'{arg1}' odada bulunamadı.",
                f"<#ff4444>\u274c <#ffffff>'{arg1}' was not found in the room.",
            ))
            return
        removed = data.remove_vip(target_user.id)
        if removed:
            await self.highrise.chat(self._t(
                f"<#00ff88>\u2705 {target_user.username} <#ffffff>VIP'ten çıkarıldı.",
                f"<#00ff88>\u2705 {target_user.username} <#ffffff>was removed from VIP.",
            ))
        else:
            await self.highrise.chat(self._t(
                f"<#ff4444>\u274c {target_user.username} <#ffffff>zaten VIP değil.",
                f"<#ff4444>\u274c {target_user.username} <#ffffff>is not VIP.",
            ))

    async def on_tip(self, sender: User, receiver: User, tip) -> None:
        from highrise.models import CurrencyItem
        if not isinstance(tip, CurrencyItem):
            return
        if tip.type.lower() != "gold":
            return

        amount = tip.amount

        if amount >= 300:
            data.add_vip(sender.id, sender.username)
            await self.highrise.chat(self._t(
                f"<#cc44ff>\u2b50 {sender.username} <#ffbf00>300 Gold <#ffffff>attı ve otomatik <#cc44ff>VIP <#ffffff>oldu!\n"
                f"<#ffaa00>Sınırsız coin <#ffffff>+ <#cc44ff>öncelikli kuyruk <#ffffff>kazandı! \U0001f389",
                f"<#cc44ff>\u2b50 {sender.username} sent <#ffbf00>300 Gold <#ffffff>and is now automatically <#cc44ff>VIP<#ffffff>!\n"
                f"<#ffaa00>Unlimited coins <#ffffff>+ <#cc44ff>priority queue <#ffffff>unlocked! \U0001f389",
            ))
        elif amount >= 200:
            new_bal = data.add_coins(sender.id, sender.username, 2000)
            await self.highrise.chat(self._t(
                f"<#ff6699>\U0001f4b0 {sender.username} <#ffbf00>200 Gold <#ffffff>attı ve <#ffaa00>2000 coin <#ffffff>kazandı!\n"
                f"<#ffffff>Yeni bakiye: <#ffaa00>{new_bal} coin \U0001f381",
                f"<#ff6699>\U0001f4b0 {sender.username} sent <#ffbf00>200 Gold <#ffffff>and received <#ffaa00>2000 coins<#ffffff>!\n"
                f"<#ffffff>New balance: <#ffaa00>{new_bal} coins \U0001f381",
            ))
        elif amount >= 100:
            new_bal = data.add_coins(sender.id, sender.username, 1000)
            await self.highrise.chat(self._t(
                f"<#ff6699>\U0001f4b0 {sender.username} <#ffbf00>100 Gold <#ffffff>attı ve <#ffaa00>1000 coin <#ffffff>kazandı!\n"
                f"<#ffffff>Yeni bakiye: <#ffaa00>{new_bal} coin \U0001f381",
                f"<#ff6699>\U0001f4b0 {sender.username} sent <#ffbf00>100 Gold <#ffffff>and received <#ffaa00>1000 coins<#ffffff>!\n"
                f"<#ffffff>New balance: <#ffaa00>{new_bal} coins \U0001f381",
            ))

    async def _cmd_room(self, user: User, arg1: str, arg2: str) -> None:
        if not _is_admin(user):
            await self.highrise.chat(self._t(
                "\u274c Bu komut sadece admine özel.",
                "\u274c This command is for the admin only.",
            ))
            return
        if not arg1:
            await self.highrise.chat(self._t(
                "\u274c Kullanım: !room <oda_id>",
                "\u274c Usage: !room <room_id>",
            ))
            return

        new_room_id = arg1.strip()
        await self.highrise.chat(self._t(
            f"<#00ccff>\U0001f6aa <#ffffff>Odaya geçiliyor: <#ffbf00>{new_room_id}",
            f"<#00ccff>\U0001f6aa <#ffffff>Moving to room: <#ffbf00>{new_room_id}",
        ))
        data.save_room_id(new_room_id)

        try:
            sys.exit(0)
        except SystemExit:
            raise

    async def _cmd_restart(self, user: User, arg1: str, arg2: str) -> None:
        if not _is_privileged(user):
            await self.highrise.chat(self._t(
                "\u274c Bu komut sadece host/admin için.",
                "\u274c This command is only for hosts/admins.",
            ))
            return

        await self.highrise.chat(self._t(
            "<#00ccff>\U0001f504 <#ffffff>Bot yeniden başlatılıyor...",
            "<#00ccff>\U0001f504 <#ffffff>Bot is restarting...",
        ))

        try:
            sys.exit(0)
        except SystemExit:
            raise

    async def _cmd_deltele(self, user: User, arg1: str, arg2: str) -> None:
        if not _is_role_manager(user):
            await self.highrise.chat(self._t(
                "\u274c Bu komut sadece admine özel.",
                "\u274c This command is for the admin only.",
            ))
            return
        name = arg1.strip().lower()
        if not name:
            await self.highrise.chat(self._t(
                "\u274c Kullanım: !deltele <isim>",
                "\u274c Usage: !deltele <name>",
            ))
            return
        if data.delete_teleport(name):
            await self.highrise.chat(self._t(
                f"<#ff4444>\U0001f5d1 <#ffffff>Işınlanma noktası silindi: <#ffbf00>{name}",
                f"<#ff4444>\U0001f5d1 <#ffffff>Teleport point deleted: <#ffbf00>{name}",
            ))
        else:
            await self.highrise.chat(self._t(
                f"<#ff4444>\u274c <#ffffff>'{name}' adında bir nokta yok.",
                f"<#ff4444>\u274c <#ffffff>There is no point named '{name}'.",
            ))

    async def _cmd_teleports(self, user: User, arg1: str, arg2: str) -> None:
        teleports = data.get_teleports()
        if not teleports:
            await self.highrise.chat(self._t(
                "<#888888>\U0001f4ed Kayıtlı ışınlanma noktası yok.",
                "<#888888>\U0001f4ed No teleport points are saved.",
            ))
            return
        names = ", ".join(f"!{n}" for n in teleports)
        await self.highrise.chat(self._t(
            f"<#ffbf00>\U0001f4cd IŞINLANMA NOKTALARI:\n<#ffffff>{names}",
            f"<#ffbf00>\U0001f4cd TELEPORT POINTS:\n<#ffffff>{names}",
        ))

    async def _cmd_setbot(self, user: User, arg1: str, arg2: str) -> None:
        if not _is_privileged(user):
            await self.highrise.chat(self._t(
                "<#ff4444>\u274c <#ffffff>Sadece admin/host kullanabilir.",
                "<#ff4444>\u274c <#ffffff>Only the admin/host can use this.",
            ))
            return

        try:
            if arg1 and arg2:
                try:
                    x, y, z = float(arg1), 0.0, float(arg2)
                except ValueError:
                    await self.highrise.chat(self._t(
                        "<#ff4444>\u274c <#ffffff>Kullanım: !setbot <x> <z>",
                        "<#ff4444>\u274c <#ffffff>Usage: !setbot <x> <z>",
                    ))
                    return
            else:
                try:
                    resp = await self.highrise.get_room_users()
                    room_users = resp.content if hasattr(resp, "content") else []
                except Exception:
                    room_users = []

                found = False
                for u, pos in room_users:
                    if u.id == user.id and hasattr(pos, "x"):
                        x, y, z = pos.x, pos.y, pos.z
                        found = True
                        break

                if not found:
                    await self.highrise.chat(self._t(
                        "<#ff4444>\u274c <#ffffff>Konumun alınamadı. !setbot <x> <z> şeklinde dene.",
                        "<#ff4444>\u274c <#ffffff>Your position could not be found. Try !setbot <x> <z>.",
                    ))
                    return

            await self.highrise.walk_to(Position(x, y, z))
            data.save_position(x, y, z)
            await self.highrise.chat(self._t(
                f"<#00ff88>\U0001f4cd <#ffffff>Konum kaydedildi: <#ffbf00>({x:.1f}, {y:.1f}, {z:.1f})",
                f"<#00ff88>\U0001f4cd <#ffffff>Position saved: <#ffbf00>({x:.1f}, {y:.1f}, {z:.1f})",
            ))
        except Exception as e:
            await self.highrise.chat(self._t(
                f"<#ff4444>\u274c <#ffffff>Konum ayarlanamadı: {e}",
                f"<#ff4444>\u274c <#ffffff>Position could not be set: {e}",
            ))

    async def _cmd_outfit(self, user: User, arg1: str, arg2: str) -> None:
        if not _is_privileged(user):
            await self.highrise.chat(self._t(
                "\u274c Bu komut sadece admin ve hostlara özel.",
                "\u274c This command is only for admins and hosts.",
            ))
            return
        if not arg1:
            await self.highrise.chat(self._t(
                "\u274c Kullanım: !o <item_id>",
                "\u274c Usage: !o <item_id>",
            ))
            return

        item_id = (arg1 + " " + arg2).strip()

        try:
            current_resp = await self.highrise.get_my_outfit()
            current_items = current_resp.outfit if hasattr(current_resp, "outfit") else []

            new_item = Item(id=item_id, type="clothing", amount=1, account_bound=False, active_palette=None)

            item_type_prefix = item_id.split("_")[0].lower() if "_" in item_id else ""
            filtered = [it for it in current_items if not it.id.startswith(item_type_prefix)] if item_type_prefix else current_items
            new_outfit = filtered + [new_item]

            await self.highrise.set_outfit(new_outfit)

            outfit_data = [{"id": it.id, "type": it.type, "amount": it.amount, "account_bound": it.account_bound, "active_palette": it.active_palette} for it in new_outfit]
            data.save_outfit(outfit_data)

            await self.highrise.chat(self._t(
                f"<#cc44ff>\U0001f457 <#ffffff>Kıyafet güncellendi: <#ffbf00>{item_id}",
                f"<#cc44ff>\U0001f457 <#ffffff>Outfit updated: <#ffbf00>{item_id}",
            ))
        except Exception as e:
            await self.highrise.chat(self._t(
                f"\u274c Kıyafet değiştirilemedi: {e}",
                f"\u274c Outfit could not be changed: {e}",
            ))

    async def _cmd_del(self, user: User, arg1: str, arg2: str) -> None:
        if data.is_banned(user.id):
            return
        queue_list = list(self.queue)
        idx = None
        for i, t in enumerate(queue_list):
            if t.requested_by and t.requested_by.lower() == user.username.lower():
                idx = i
                break
        if idx is None:
            await self.highrise.chat(self._t(
                f"\u274c {user.username}, kuyrukta senin şarkın yok.",
                f"\u274c {user.username}, you have no song in the queue.",
            ))
            return
        removed = queue_list.pop(idx)
        self.queue = deque(queue_list)
        await self.highrise.chat(self._t(
            f"<#ff4444>\U0001f5d1 {user.username} <#ffffff>şarkısını sildi: <#888888>{removed.title}",
            f"<#ff4444>\U0001f5d1 {user.username} <#ffffff>removed their song: <#888888>{removed.title}",
        ))

    async def _cmd_up(self, user: User, arg1: str, arg2: str) -> None:
        if data.is_banned(user.id):
            return
        queue_list = list(self.queue)
        if len(queue_list) < 2:
            await self.highrise.chat(self._t(
                "\u274c Kuyrukta yeterli şarkı yok.",
                "\u274c There are not enough songs in the queue.",
            ))
            return

        idx = None
        for i, t in enumerate(queue_list):
            if t.requested_by and t.requested_by.lower() == user.username.lower():
                idx = i
                break

        if idx is None:
            await self.highrise.chat(self._t(
                f"\u274c {user.username}, kuyrukta senin şarkın yok.",
                f"\u274c {user.username}, you have no song in the queue.",
            ))
            return
        if idx == 0:
            await self.highrise.chat(self._t(
                f"\u274c {user.username}, şarkın zaten en üstte!",
                f"\u274c {user.username}, your song is already at the top!",
            ))
            return

        if not _is_unlimited(user):
            coins = data.get_coins(user.id, user.username)
            if coins < 50:
                await self.highrise.chat(self._t(
                    f"\U0001f4b8 {user.username}, 1 sıra yukarı taşımak için 50 coin gerekli! Bakiye: {coins}",
                    f"\U0001f4b8 {user.username}, 50 coins are required to move up one spot! Balance: {coins}",
                ))
                return
            data.add_coins(user.id, user.username, -50)

        queue_list[idx], queue_list[idx - 1] = queue_list[idx - 1], queue_list[idx]
        self.queue = deque(queue_list)
        await self.highrise.chat(self._t(
            f"<#00ccff>\u2b06 {user.username} <#ffffff>şarkısını 1 sıra yukarı taşıdı: <#ffbf00>{queue_list[idx - 1].title}",
            f"<#00ccff>\u2b06 {user.username} <#ffffff>moved their song up one spot: <#ffbf00>{queue_list[idx - 1].title}",
        ))

    async def _cmd_url(self, user: User, arg1: str, arg2: str) -> None:
        if not _is_role_manager(user):
            await self._chat(self._t(
                "Bu komut adminlere özel.\u274c",
                "This command is for the admin only.\u274c",
            ))
            return

        stream_url = os.environ.get("RADIO_STREAM_URL", "")
        if not stream_url:
            await self._whisper(user.id, self._t(
                "\u274c Yayın URL'si henüz ayarlanmamış.",
                "\u274c The stream URL has not been configured yet.",
            ))
            return

        msg = self._t(
            f"\U0001f4fb Radyo Stream URL:\n{stream_url}\n\n"
            f"Bu URL'yi oda radyo ayarlarına gir.\n"
            f"Şu an sırada {len(self.queue)} şarkı var.",
            f"\U0001f4fb Radio stream URL:\n{stream_url}\n\n"
            f"Enter this URL in the room radio settings.\n"
            f"There are currently {len(self.queue)} songs in the queue.",
        )
        await self._whisper(user.id, msg)

    async def _cmd_help(self, user: User, arg1: str, arg2: str) -> None:
        help_messages = [
            (
                "<#ffbf00>\U0001f3b5 -p <şarkı/link> — Şarkıyı arar ve kuyruğa ekler. Ücret: 100 coin.",
                "<#ffbf00>\U0001f3b5 -p <song/link> — Search and add a song. Cost: 100 coins.",
            ),
            (
                "<#ffbf00>!play <şarkı/link> — Şarkıyı arar ve kuyruğa ekler. Örnek: !play Tarkan Şımarık",
                "<#ffbf00>!play <song/link> — Search and add a song. Example: !play Tarkan Şımarık",
            ),
            (
                "<#00ccff>📻 İstek yokken otomatik radyo çalar; yeni istek gelince radyoyu keser.",
                "<#00ccff>📻 Auto radio plays when the queue is empty and yields to new requests.",
            ),
            (
                "<#00ccff>!queue — Çalan ve sıradaki şarkıları gösterir.",
                "<#00ccff>!queue — Shows the current and queued songs.",
            ),
            (
                "<#00ccff>!np / !nowplaying — Şu an çalan şarkıyı gösterir.",
                "<#00ccff>!np / !nowplaying — Shows the currently playing song.",
            ),
            (
                "<#00ccff>!del — Kuyruktaki kendi şarkını siler.",
                "<#00ccff>!del — Removes your own song from the queue.",
            ),
            (
                "<#00ccff>!up — Kendi şarkını bir sıra yukarı taşır. Ücret: 50 coin.",
                "<#00ccff>!up — Moves your own song one place up. Cost: 50 coins.",
            ),
            (
                "<#ff6699>/fav — Şu an çalan şarkıyı favorilerine ekler.",
                "<#ff6699>/fav — Adds the current song to your favorites.",
            ),
            (
                "<#ffaa00>!coin — Coin bakiyeni gösterir.",
                "<#ffaa00>!coin — Shows your coin balance.",
            ),
            (
                "<#ffaa00>!puan / !top — En yüksek coin bakiyesine sahip ilk 10 kişiyi gösterir.",
                "<#ffaa00>!puan / !top — Shows the top 10 users with the highest coin balance.",
            ),
            (
                "<#ffaa00>!daily — Her gün 100 coin verir.",
                "<#ffaa00>!daily — Gives you 100 coins once per day.",
            ),
            (
                "<#ffaa00>!give @kullanıcı <miktar> — Başka kullanıcıya coin gönderir.",
                "<#ffaa00>!give @user <amount> — Sends coins to another user.",
            ),
            (
                "<#ffaa00>!help — Bu komut listesini her komut için ayrı mesaj olarak gösterir.",
                "<#ffaa00>!help — Shows this command list, one command per message.",
            ),
            (
                "<#ffaa00>!lan tr — Botu Türkçe yapar. Sadece admin kullanabilir.",
                "<#ffaa00>!lan tr — Changes the bot to Turkish. Admin only.",
            ),
            (
                "<#ffaa00>!lan eng — Botu İngilizce yapar. Sadece admin kullanabilir.",
                "<#ffaa00>!lan eng — Changes the bot to English. Admin only.",
            ),
            (
                "<#cc44ff>\U0001f451 !skip — Çalan şarkıyı geçer. Admin/host.",
                "<#cc44ff>\U0001f451 !skip — Skips the current song. Admin/host.",
            ),
            (
                "<#cc44ff>\U0001f451 !stop — Müziği/radyoyu durdurur ve kuyruğu temizler. Admin/host.",
                "<#cc44ff>\U0001f451 !stop — Stops music/radio and clears the queue. Admin/host.",
            ),
            (
                "<#cc44ff>\U0001f451 !ban @kullanıcı — Kullanıcının müzik çalmasını engeller. Admin/host.",
                "<#cc44ff>\U0001f451 !ban @user — Stops a user from playing music. Admin/host.",
            ),
            (
                "<#cc44ff>\U0001f451 !unban @kullanıcı — Kullanıcının müzik yasağını kaldırır. Admin/host.",
                "<#cc44ff>\U0001f451 !unban @user — Removes a user's music ban. Admin/host.",
            ),
            (
                "<#cc44ff>\U0001f451 !addhost @kullanıcı — Kullanıcıyı host yapar. Bot sahibi/admin.",
                "<#cc44ff>\U0001f451 !addhost @user — Makes a user a host. Bot owner/admin.",
            ),
            (
                "<#cc44ff>\U0001f451 !removehost @kullanıcı — Host yetkisini kaldırır. Bot sahibi/admin.",
                "<#cc44ff>\U0001f451 !removehost @user — Removes host access. Bot owner/admin.",
            ),
            (
                "<#cc44ff>\U0001f451 !addvip @kullanıcı — Kullanıcıyı VIP yapar. Bot sahibi/admin/host.",
                "<#cc44ff>\U0001f451 !addvip @user — Makes a user VIP. Bot owner/admin/host.",
            ),
            (
                "<#cc44ff>\U0001f451 !removevip @kullanıcı — VIP yetkisini kaldırır. Bot sahibi/admin/host.",
                "<#cc44ff>\U0001f451 !removevip @user — Removes VIP access. Bot owner/admin/host.",
            ),
            (
                "<#cc44ff>\U0001f451 !botemote <isim> — Bot emote yapar. Örnek: !botemote floss",
                "<#cc44ff>\U0001f451 !botemote <name> — Makes the bot emote. Example: !botemote floss",
            ),
            (
                "<#cc44ff>\U0001f451 !loop <mesaj> — Mesajı 30 saniyede bir tekrarlar; !loop ile durur.",
                "<#cc44ff>\U0001f451 !loop <message> — Repeats every 30 seconds; use !loop to stop.",
            ),
            (
                "<#cc44ff>\U0001f451 !welcome <mesaj> — Yeni gelenleri karşılar. İsim için {user}; kapat: !welcome off",
                "<#cc44ff>\U0001f451 !welcome <message> — Welcomes new users. Use {user}; disable: !welcome off",
            ),
            (
                "<#cc44ff>\U0001f451 !goodbye <mesaj> — Ayrılanlara mesaj gönderir. İsim için {user}; kapat: !goodbye off",
                "<#cc44ff>\U0001f451 !goodbye <message> — Says goodbye to users. Use {user}; disable: !goodbye off",
            ),
            (
                "<#cc44ff>\U0001f451 !kelime — Tek ipucu verir; 35 sn içinde bilen kazanır, yoksa cevap açıklanır.",
                "<#cc44ff>\U0001f451 !kelime — Gives one hint; guess within 35 sec or the answer is revealed.",
            ),
            (
                "<#cc44ff>\U0001f451 !kelimedur — Kelime ipucu göndermeyi durdurur.",
                "<#cc44ff>\U0001f451 !kelimedur — Stops the word hints.",
            ),
            (
                "<#cc44ff>\U0001f451 !m @kullanıcı — Bot sahibini atar. Sadece ana admin.",
                "<#cc44ff>\U0001f451 !m @user — Assigns the bot owner. Primary admin only.",
            ),
            (
                "<#cc44ff>\U0001f451 !setbot [x] [z] — Botun konumunu kaydeder veya verilen konuma götürür. Admin/host.",
                "<#cc44ff>\U0001f451 !setbot [x] [z] — Saves or sets the bot position. Admin/host.",
            ),
            (
                "<#cc44ff>\U0001f451 !o <item_id> — Botun kıyafetini değiştirir. Admin/host.",
                "<#cc44ff>\U0001f451 !o <item_id> — Changes the bot outfit. Admin/host.",
            ),
            (
                "<#cc44ff>\U0001f451 !copy @kullanıcı — Kullanıcının kıyafetini kopyalar. Admin/host.",
                "<#cc44ff>\U0001f451 !copy @user — Copies a user's outfit. Admin/host.",
            ),
            (
                "<#cc44ff>\U0001f451 !room <oda_id> — Botu başka odaya taşır. Sadece ana admin.",
                "<#cc44ff>\U0001f451 !room <room_id> — Moves the bot to another room. Primary admin only.",
            ),
            (
                "<#cc44ff>\U0001f451 !restart — Botu yeniden başlatır. Admin/host.",
                "<#cc44ff>\U0001f451 !restart — Restarts the bot. Admin/host.",
            ),
            (
                "<#cc44ff>\U0001f451 !url — Radyo yayın adresini whisper ile gönderir. Bot sahibi/admin.",
                "<#cc44ff>\U0001f451 !url — Sends the radio stream URL by whisper. Bot owner/admin.",
            ),
            (
                "<#cc44ff>\U0001f451 !teleports — Kayıtlı ışınlanma noktalarını gösterir.",
                "<#cc44ff>\U0001f451 !teleports — Shows saved teleport points.",
            ),
            (
                "<#cc44ff>\U0001f451 !deltele <isim> — Işınlanma noktasını siler. Sadece admin.",
                "<#cc44ff>\U0001f451 !deltele <name> — Deletes a teleport point. Admin only.",
            ),
            (
                "<#cc44ff>\U0001f451 !k1 — Adminin bulunduğu konumu k1 olarak kaydeder; herkes k1 yazarak ışınlanır.",
                "<#cc44ff>\U0001f451 !k1 — Saves the admin's position as k1; anyone can type k1 to teleport.",
            ),
        ]

        for index, (turkish, english) in enumerate(help_messages):
            try:
                await self.highrise.send_whisper(user.id, self._t(turkish, english))
            except Exception as e:
                print(f"[Bot] Help mesajı gönderilemedi ({index + 1}): {e}")
            if index < len(help_messages) - 1:
                await asyncio.sleep(1.2)

    async def _cmd_fav(self, user: User) -> None:
        if not self.current_track:
            await self.highrise.chat(self._t(
                "<#ff4444>\u274c <#ffffff>Şu an çalan şarkı yok.",
                "<#ff4444>\u274c <#ffffff>There is no song playing right now.",
            ))
            return

        track_data = {
            "title": self.current_track.title,
            "url": self.current_track.url,
            "duration_seconds": self.current_track.duration_seconds,
            "query": self.current_track.title,
        }

        success, _ = data.add_favorite(user.id, user.username, track_data)
        title_short = self.current_track.title[:45] + ("..." if len(self.current_track.title) > 45 else "")

        if not success:
            await self.highrise.chat(self._t(
                f"<#ffaa00>\u26a0\ufe0f {user.username}<#ffffff>, bu şarkı zaten favorilerinde!",
                f"<#ffaa00>\u26a0\ufe0f {user.username}<#ffffff>, this song is already in your favorites!",
            ))
            return

        if _is_admin(user):
            await self.highrise.chat(self._t(
                f"<#ff6699>\u2764\ufe0f {user.username} <#ffffff>favorilere ekledi ve radyoya alındı!\n"
                f"<#ffbf00>{title_short}",
                f"<#ff6699>\u2764\ufe0f {user.username} <#ffffff>added it to favorites and the radio!\n"
                f"<#ffbf00>{title_short}",
            ))
        else:
            await self.highrise.chat(self._t(
                f"<#ff6699>\u2764\ufe0f {user.username} <#ffffff>favorilere ekledi!\n"
                f"<#ffbf00>{title_short}",
                f"<#ff6699>\u2764\ufe0f {user.username} <#ffffff>added it to favorites!\n"
                f"<#ffbf00>{title_short}",
            ))

    async def _cmd_copy(self, user: User, arg1: str, arg2: str) -> None:
        if not _is_privileged(user):
            await self.highrise.chat(self._t(
                f"<#ff4444>\u274c {user.username}<#ffffff>, bu komut sadece admin ve hostlara özel.",
                f"<#ff4444>\u274c {user.username}<#ffffff>, this command is only for admins and hosts.",
            ))
            return
        if not arg1:
            await self.highrise.chat(self._t(
                "<#ff4444>\u274c <#ffffff>Kullanım: !copy @kullanıcı",
                "<#ff4444>\u274c <#ffffff>Usage: !copy @user",
            ))
            return

        target_user = await self._find_room_user(arg1)
        if not target_user:
            await self.highrise.chat(self._t(
                f"<#ff4444>\u274c <#ffffff>'{arg1}' odada bulunamadı.",
                f"<#ff4444>\u274c <#ffffff>'{arg1}' was not found in the room.",
            ))
            return

        try:
            outfit_resp = await self.highrise.get_user_outfit(target_user.id)
            outfit_items = outfit_resp.outfit if hasattr(outfit_resp, "outfit") else []
            if not outfit_items:
                await self.highrise.chat(self._t(
                    f"<#ff4444>\u274c <#ffffff>{target_user.username} kıyafeti alınamadı.",
                    f"<#ff4444>\u274c <#ffffff>Could not get {target_user.username}'s outfit.",
                ))
                return

            await self.highrise.set_outfit(outfit_items)

            outfit_data = [{"id": it.id, "type": it.type, "amount": it.amount, "account_bound": it.account_bound, "active_palette": it.active_palette} for it in outfit_items]
            data.save_outfit(outfit_data)

            await self.highrise.chat(self._t(
                f"<#cc44ff>\U0001f457 <#ffffff>{target_user.username} kıyafeti kopyalandı!",
                f"<#cc44ff>\U0001f457 <#ffffff>Copied {target_user.username}'s outfit!",
            ))
        except Exception as e:
            await self.highrise.chat(self._t(
                f"<#ff4444>\u274c <#ffffff>Kıyafet kopyalanamadı: {e}",
                f"<#ff4444>\u274c <#ffffff>Could not copy the outfit: {e}",
            ))

    async def _emote_loop(self, emote_id: str) -> None:
        try:
            while True:
                try:
                    await self.highrise.send_emote(emote_id)
                except Exception as e:
                    print(f"[Bot] Emote hata: {e}")
                await asyncio.sleep(8)
        except asyncio.CancelledError:
            pass

    async def _cmd_botemote(self, user: User, arg1: str, arg2: str) -> None:
        if not _is_privileged(user):
            await self.highrise.chat(self._t(
                f"<#ff4444>\u274c {user.username}<#ffffff>, bu komut sadece admin ve hostlara özel.",
                f"<#ff4444>\u274c {user.username}<#ffffff>, this command is only for admins and hosts.",
            ))
            return

        if not arg1:
            if self._emote_task and not self._emote_task.done():
                self._emote_task.cancel()
                self._current_emote = None
                await self.highrise.chat(self._t(
                    "<#ffbf00>\U0001f57a <#ffffff>Dans durduruldu.",
                    "<#ffbf00>\U0001f57a <#ffffff>Dance stopped.",
                ))
            else:
                await self.highrise.chat(self._t(
                    "<#ff4444>\u274c <#ffffff>Kullanım: !botemote <emote_adı> | Durdurmak için: !botemote",
                    "<#ff4444>\u274c <#ffffff>Usage: !botemote <emote_name> | Stop with: !botemote",
                ))
            return

        emote_map = {
            "floss": "dance-floss",
            "tiktok": "dance-tiktok8",
            "tiktok1": "dance-tiktok1",
            "tiktok2": "dance-tiktok2",
            "shuffle": "dance-shuffle",
            "blackpink": "dance-blackpink",
            "gangnam": "dance-gangnam",
            "macarena": "dance-macarena",
            "robot": "dance-robot",
            "wave": "emote-wave",
            "kiss": "emote-kiss",
            "cry": "emote-cry",
            "laugh": "emote-laugh",
            "clap": "emote-clap",
            "no": "emote-no",
            "yes": "emote-yes",
            "hello": "emote-hello",
            "float": "idle-float",
            "sit": "idle-sit",
        }

        raw = (arg1 + (" " + arg2 if arg2 else "")).strip()
        emote_id = emote_map.get(raw.lower(), raw)

        if self._emote_task and not self._emote_task.done():
            self._emote_task.cancel()

        self._current_emote = emote_id
        self._emote_task = asyncio.create_task(self._emote_loop(emote_id))
        await self.highrise.chat(self._t(
            f"<#ffbf00>\U0001f57a Bot dans ediyor: <#ffffff>{raw}",
            f"<#ffbf00>\U0001f57a Bot is dancing: <#ffffff>{raw}",
        ))

    async def _loop_message_task(self) -> None:
        try:
            while True:
                await asyncio.sleep(30)
                if self._loop_text:
                    try:
                        await self._chat(self._loop_text)
                    except Exception as e:
                        print(f"[Bot] Loop mesaj hata: {e}")
        except asyncio.CancelledError:
            pass

    async def _cmd_loop(self, user: User, arg1: str, arg2: str) -> None:
        if not _is_privileged(user):
            await self.highrise.chat(self._t(
                f"<#ff4444>\u274c {user.username}<#ffffff>, bu komut sadece admin ve hostlara özel.",
                f"<#ff4444>\u274c {user.username}<#ffffff>, this command is only for admins and hosts.",
            ))
            return

        text = (arg1 + (" " + arg2 if arg2 else "")).strip()

        if not text:
            has_loop = bool(self._loop_text or data.get_loop_text())
            if self._loop_task and not self._loop_task.done():
                self._loop_task.cancel()
            if has_loop:
                self._loop_text = None
                data.set_loop_text(None)
                await self.highrise.chat(self._t(
                    "<#ff4444>\U0001f507 <#ffffff>Döngü mesajı durduruldu.",
                    "<#ff4444>\U0001f507 <#ffffff>Loop message stopped.",
                ))
            else:
                await self.highrise.chat(self._t(
                    "<#ff4444>\u274c <#ffffff>Kullanım: !loop <metin> | Durdurmak için: !loop",
                    "<#ff4444>\u274c <#ffffff>Usage: !loop <message> | Stop with: !loop",
                ))
            return

        if self._loop_task and not self._loop_task.done():
            self._loop_task.cancel()

        self._loop_text = text
        data.set_loop_text(text)
        self._loop_task = asyncio.create_task(self._loop_message_task())
        await self.highrise.chat(self._t(
            f"<#00ff88>\U0001f501 <#ffffff>Döngü mesajı ayarlandı <#888888>(30sn'de bir):<#ffffff>\n{text}",
            f"<#00ff88>\U0001f501 <#ffffff>Loop message set <#888888>(every 30s):<#ffffff>\n{text}",
        ))

    async def _cmd_welcome(self, user: User, arg1: str, arg2: str) -> None:
        if not _is_privileged(user):
            await self.highrise.chat(self._t(
                f"<#ff4444>\u274c {user.username}<#ffffff>, bu komut sadece admin ve hostlara özel.",
                f"<#ff4444>\u274c {user.username}<#ffffff>, this command is only for admins and hosts.",
            ))
            return

        text = (arg1 + (" " + arg2 if arg2 else "")).strip()
        if text.lower() in {"off", "kapat", "disable"}:
            data.set_welcome_text(None)
            await self.highrise.chat(self._t(
                "<#ffbf00>\U0001f44b Hoş geldin mesajı kapatıldı.",
                "<#ffbf00>\U0001f44b Welcome message disabled.",
            ))
            return

        if not text:
            current = data.get_welcome_text()
            if current:
                await self.highrise.chat(self._t(
                    f"<#00ccff>\U0001f44b Mevcut hoş geldin mesajı: <#ffffff>{current}\n"
                    "<#888888>Değiştirmek için: !welcome <mesaj> | Kapatmak için: !welcome off",
                    f"<#00ccff>\U0001f44b Current welcome message: <#ffffff>{current}\n"
                    "<#888888>Change with: !welcome <message> | Disable with: !welcome off",
                ))
            else:
                await self.highrise.chat(self._t(
                    "<#ff4444>\u274c <#ffffff>Kullanım: !welcome <mesaj> "
                    "(isim için {user}) | Kapatmak için: !welcome off",
                    "<#ff4444>\u274c <#ffffff>Usage: !welcome <message> "
                    "(use {user} for the name) | Disable with: !welcome off",
                ))
            return

        data.set_welcome_text(text)
        await self.highrise.chat(self._t(
            f"<#00ff88>\U0001f44b <#ffffff>Hoş geldin mesajı ayarlandı:\n{text}",
            f"<#00ff88>\U0001f44b <#ffffff>Welcome message set:\n{text}",
        ))

    async def _cmd_goodbye(self, user: User, arg1: str, arg2: str) -> None:
        if not _is_privileged(user):
            await self.highrise.chat(self._t(
                f"<#ff4444>\u274c {user.username}<#ffffff>, bu komut sadece admin ve hostlara özel.",
                f"<#ff4444>\u274c {user.username}<#ffffff>, this command is only for admins and hosts.",
            ))
            return

        text = (arg1 + (" " + arg2 if arg2 else "")).strip()
        if text.lower() in {"off", "kapat", "disable"}:
            data.set_goodbye_text(None)
            await self.highrise.chat(self._t(
                "<#ffbf00>\U0001f44b Ayrılma mesajı kapatıldı.",
                "<#ffbf00>\U0001f44b Goodbye message disabled.",
            ))
            return

        if not text:
            current = data.get_goodbye_text()
            if current:
                await self.highrise.chat(self._t(
                    f"<#00ccff>\U0001f44b Mevcut ayrılma mesajı: <#ffffff>{current}\n"
                    "<#888888>Değiştirmek için: !goodbye <mesaj> | Kapatmak için: !goodbye off",
                    f"<#00ccff>\U0001f44b Current goodbye message: <#ffffff>{current}\n"
                    "<#888888>Change with: !goodbye <message> | Disable with: !goodbye off",
                ))
            else:
                await self.highrise.chat(self._t(
                    "<#ff4444>\u274c <#ffffff>Kullanım: !goodbye <mesaj> "
                    "(isim için {user}) | Kapatmak için: !goodbye off",
                    "<#ff4444>\u274c <#ffffff>Usage: !goodbye <message> "
                    "(use {user} for the name) | Disable with: !goodbye off",
                ))
            return

        data.set_goodbye_text(text)
        await self.highrise.chat(self._t(
            f"<#00ff88>\U0001f44b <#ffffff>Ayrılma mesajı ayarlandı:\n{text}",
            f"<#00ff88>\U0001f44b <#ffffff>Goodbye message set:\n{text}",
        ))

    async def _start_playback(self) -> None:
        if self._play_task and not self._play_task.done():
            self._play_task.cancel()
        self._play_task = asyncio.create_task(self._playback_loop())

    async def _search_auto_radio_track(self) -> Optional[Track]:
        catalog = AUTO_RADIO_EN if self.language == "eng" else AUTO_RADIO_TR
        candidates = [query for query in catalog if query not in self._auto_radio_recent]
        if not candidates:
            self._auto_radio_recent.clear()
            candidates = list(catalog)

        query = random.choice(candidates)
        self._auto_radio_recent.append(query)
        try:
            track = await self.player.search(query)
        except asyncio.CancelledError:
            raise
        except Exception as e:
            print(f"[Radio] Otomatik radyo araması başarısız ({query!r}): {e}")
            return None

        if track:
            track.requested_by = self._t("Otomatik radyo", "Auto radio")
        return track

    async def _report_unplayable_track(self, track: Track) -> None:
        title = track.title[:55] + ("..." if len(track.title) > 55 else "")
        refunded = False
        refund_amount = track.coins_charged
        if refund_amount > 0 and track.requested_by_id:
            data.add_coins(
                track.requested_by_id,
                track.requested_by or self._t("Bilinmiyor", "Unknown"),
                refund_amount,
            )
            track.coins_charged = 0
            refunded = True

        if refunded:
            message = self._t(
                f"❌ {title} çalınamadı; {refund_amount} coin iade edildi.",
                f"❌ Couldn't play {title}; {refund_amount} coins were refunded.",
            )
        else:
            message = self._t(
                f"❌ {title} için kullanılabilir ses kaynağı bulunamadı; istek atlandı.",
                f"❌ No playable audio source for {title}; request skipped.",
            )
        try:
            await self._chat(message)
        except Exception as e:
            print(f"[Radio] Çalınamayan şarkı bildirilemedi: {e}")

    async def _playback_loop(self) -> None:
        while True:
            if self.queue:
                self._auto_radio_active = False
                self.current_track = self.queue.popleft()
            else:
                self._auto_radio_active = True
                self.is_playing = True
                try:
                    automatic_track = await self._search_auto_radio_track()
                except asyncio.CancelledError:
                    if asyncio.current_task() is self._play_task:
                        self._auto_radio_active = False
                        self.is_playing = False
                        self.current_track = None
                    return

                if self.queue:
                    self._auto_radio_active = False
                    continue
                if not automatic_track:
                    self._auto_radio_active = False
                    await asyncio.sleep(3)
                    continue
                self.current_track = automatic_track

            self.is_playing = True

            title_short = self.current_track.title[:55] + ("..." if len(self.current_track.title) > 55 else "")
            requester = (self.current_track.requested_by or self._t("Bilinmiyor", "Unknown"))[:25]

            try:
                played = False
                announced = False
                candidate_index = 0
                async for stream_url in self.player.iter_stream_urls(self.current_track):
                    candidate_index += 1
                    if not announced:
                        await self.highrise.chat(self._t(
                            f"<#00ff88>\u25b6 Çalıyor: <#ffffff>{title_short} "
                            f"<#888888>[{self.current_track.duration_str}]\n"
                            f"<#888888>\U0001f464 {requester} <#666666>\u2022 Bot: @the_alperenn",
                            f"<#00ff88>\u25b6 Playing: <#ffffff>{title_short} "
                            f"<#888888>[{self.current_track.duration_str}]\n"
                            f"<#888888>\U0001f464 {requester} <#666666>\u2022 Bot: @the_alperenn",
                        ))
                        announced = True
                    print(
                        f"[Radio] Kaynak deneniyor {candidate_index}: "
                        f"{self.current_track.title[:70]}"
                    )
                    if await self.broadcaster.play_url(stream_url):
                        played = True
                        break

                if not played:
                    if candidate_index:
                        print(f"[Radio] Kullanılabilir ses kaynağı yok: {self.current_track.title[:70]}")
                    else:
                        print(f"[Radio] Ses linki bulunamadı: {self.current_track.title[:70]}")
                    await self._report_unplayable_track(self.current_track)
            except asyncio.CancelledError:
                if asyncio.current_task() is self._play_task:
                    self._auto_radio_active = False
                    self.is_playing = False
                    self.current_track = None
                return
            except Exception as e:
                print(f"[Radio] Şarkı oynatılırken hata oluştu: {e}")
                await self._report_unplayable_track(self.current_track)

    async def _next_track(self) -> None:
        # Do NOT set is_playing=False here — that creates a window where _cmd_play
        # sees no task running and starts a duplicate task, and _cmd_skip says
        # "nothing playing" during the search. Keep is_playing=True throughout
        # the transition; the new task inherits the playing state.
        self._auto_radio_active = False
        self.current_track = None
        old_task = self._play_task
        await self._start_playback()
        if old_task and not old_task.done():
            old_task.cancel()
