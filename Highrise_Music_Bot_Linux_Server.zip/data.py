"""Simple JSON-file backed persistence for the Highrise music bot.

Not a database — just durable local state for coins, roles, favorites,
bot position/outfit, loop messages, and the last room id. Safe for single-process use.
"""

from __future__ import annotations

import json
import os
import threading
from datetime import date
from typing import Any

_LOCK = threading.Lock()
_DEFAULT_STATE_PATH = os.path.join(os.path.dirname(__file__), "storage", "state.json")
_STATE_PATH = os.path.abspath(os.environ.get("BOT_STATE_FILE", _DEFAULT_STATE_PATH))
_INITIAL_COINS = 10_000
_DEFAULT_LANGUAGE = "tr"
_SUPPORTED_LANGUAGES = {"tr", "eng"}

_DAILY_AMOUNT = 100


def _default_state() -> dict[str, Any]:
    return {
        "coins": {},
        "hosts": {},
        "vips": {},
        "banned": {},
        "favorites": {},
        "radio_extra": [],
        "position": None,
        "outfit": None,
        "room_id": None,
        "last_good_room_id": None,
        "teleports": {},
        "loop_text": None,
        "welcome_text": None,
        "goodbye_text": None,
        "word_game_enabled": True,
        "bot_owner": None,
    }


def _load() -> dict[str, Any]:
    if not os.path.exists(_STATE_PATH):
        return _default_state()
    try:
        with open(_STATE_PATH, "r", encoding="utf-8") as f:
            state = json.load(f)
    except (json.JSONDecodeError, OSError):
        return _default_state()
    base = _default_state()
    base.update(state)
    return base


def _save(state: dict[str, Any]) -> None:
    os.makedirs(os.path.dirname(_STATE_PATH), exist_ok=True)
    tmp_path = _STATE_PATH + ".tmp"
    with open(tmp_path, "w", encoding="utf-8") as f:
        json.dump(state, f, ensure_ascii=False, indent=2)
    os.replace(tmp_path, _STATE_PATH)


# ---------------------------------------------------------------------------
# Position / outfit / room
# ---------------------------------------------------------------------------

def get_position() -> dict[str, Any] | None:
    with _LOCK:
        return _load().get("position")


def save_position(x: float, y: float, z: float, facing: str = "FrontRight") -> None:
    with _LOCK:
        state = _load()
        state["position"] = {"x": x, "y": y, "z": z, "facing": facing}
        _save(state)


def get_outfit() -> list[dict[str, Any]] | None:
    with _LOCK:
        return _load().get("outfit")


def save_outfit(items: list[dict[str, Any]]) -> None:
    with _LOCK:
        state = _load()
        state["outfit"] = items
        _save(state)


def get_current_room_id() -> str | None:
    with _LOCK:
        return _load().get("room_id")


def save_room_id(room_id: str) -> None:
    with _LOCK:
        state = _load()
        state["room_id"] = room_id
        _save(state)


def get_last_good_room_id() -> str | None:
    """Last room the bot actually managed to connect to successfully."""
    with _LOCK:
        return _load().get("last_good_room_id")


def save_last_good_room_id(room_id: str) -> None:
    with _LOCK:
        state = _load()
        state["last_good_room_id"] = room_id
        _save(state)


def get_language() -> str:
    with _LOCK:
        language = _load().get("language", _DEFAULT_LANGUAGE)
    return language if language in _SUPPORTED_LANGUAGES else _DEFAULT_LANGUAGE


def set_language(language: str) -> str:
    normalized = language.strip().lower()
    if normalized == "en":
        normalized = "eng"
    if normalized not in _SUPPORTED_LANGUAGES:
        raise ValueError(f"Unsupported language: {language}")
    with _LOCK:
        state = _load()
        state["language"] = normalized
        _save(state)
    return normalized


def get_loop_text() -> str | None:
    with _LOCK:
        loop_text = _load().get("loop_text")
    return loop_text if isinstance(loop_text, str) and loop_text.strip() else None


def set_loop_text(text: str | None) -> None:
    with _LOCK:
        state = _load()
        state["loop_text"] = text.strip() if isinstance(text, str) and text.strip() else None
        _save(state)


def get_welcome_text() -> str | None:
    with _LOCK:
        welcome_text = _load().get("welcome_text")
    return welcome_text if isinstance(welcome_text, str) and welcome_text.strip() else None


def set_welcome_text(text: str | None) -> None:
    with _LOCK:
        state = _load()
        state["welcome_text"] = text.strip() if isinstance(text, str) and text.strip() else None
        _save(state)


def get_goodbye_text() -> str | None:
    with _LOCK:
        goodbye_text = _load().get("goodbye_text")
    return goodbye_text if isinstance(goodbye_text, str) and goodbye_text.strip() else None


def set_goodbye_text(text: str | None) -> None:
    with _LOCK:
        state = _load()
        state["goodbye_text"] = text.strip() if isinstance(text, str) and text.strip() else None
        _save(state)


def get_bot_owner() -> dict[str, str] | None:
    with _LOCK:
        owner = _load().get("bot_owner")
    if not isinstance(owner, dict):
        return None
    user_id = owner.get("user_id")
    username = owner.get("username")
    if not isinstance(user_id, str) or not isinstance(username, str):
        return None
    return {"user_id": user_id, "username": username}


def set_bot_owner(user_id: str | None, username: str | None) -> None:
    with _LOCK:
        state = _load()
        if user_id and username:
            state["bot_owner"] = {"user_id": user_id, "username": username}
        else:
            state["bot_owner"] = None
        _save(state)


def is_word_game_enabled() -> bool:
    with _LOCK:
        return bool(_load().get("word_game_enabled", True))


def set_word_game_enabled(enabled: bool) -> None:
    with _LOCK:
        state = _load()
        state["word_game_enabled"] = bool(enabled)
        _save(state)


# ---------------------------------------------------------------------------
# Autotele: named teleport pads, linked in pairs, for teleporting users
# between floors when they walk onto a pad's spot.
# ---------------------------------------------------------------------------

def get_teleports() -> dict[str, dict[str, Any]]:
    with _LOCK:
        return _load().get("teleports", {})


def save_teleport(name: str, position: dict[str, Any]) -> None:
    with _LOCK:
        state = _load()
        teleports = state.setdefault("teleports", {})
        teleports[name] = position
        _save(state)


def delete_teleport(name: str) -> bool:
    with _LOCK:
        state = _load()
        teleports = state.setdefault("teleports", {})
        if name not in teleports:
            return False
        del teleports[name]
        _save(state)
        return True


# ---------------------------------------------------------------------------
# Roles: host / vip / ban
# ---------------------------------------------------------------------------

def is_host(user_id: str) -> bool:
    with _LOCK:
        return user_id in _load()["hosts"]


def add_host(user_id: str, username: str) -> None:
    with _LOCK:
        state = _load()
        state["hosts"][user_id] = username
        _save(state)


def remove_host(user_id: str) -> bool:
    with _LOCK:
        state = _load()
        removed = state["hosts"].pop(user_id, None) is not None
        if removed:
            _save(state)
        return removed


def is_vip(user_id: str) -> bool:
    with _LOCK:
        return user_id in _load()["vips"]


def add_vip(user_id: str, username: str) -> None:
    with _LOCK:
        state = _load()
        state["vips"][user_id] = username
        _save(state)


def remove_vip(user_id: str) -> bool:
    with _LOCK:
        state = _load()
        removed = state["vips"].pop(user_id, None) is not None
        if removed:
            _save(state)
        return removed


def is_banned(user_id: str) -> bool:
    with _LOCK:
        return user_id in _load()["banned"]


def ban_user(user_id: str, username: str) -> None:
    with _LOCK:
        state = _load()
        state["banned"][user_id] = username
        _save(state)


def unban_user(user_id: str) -> bool:
    with _LOCK:
        state = _load()
        removed = state["banned"].pop(user_id, None) is not None
        if removed:
            _save(state)
        return removed


# ---------------------------------------------------------------------------
# Coins
# ---------------------------------------------------------------------------

def get_coins(user_id: str, username: str) -> int:
    with _LOCK:
        state = _load()
        entry = state["coins"].get(user_id)
        if entry is None:
            entry = {"username": username, "coins": _INITIAL_COINS, "last_daily": None}
            state["coins"][user_id] = entry
            _save(state)
        return int(entry["coins"])


def add_coins(user_id: str, username: str, delta: int) -> int:
    with _LOCK:
        state = _load()
        entry = state["coins"].get(user_id)
        if entry is None:
            entry = {"username": username, "coins": _INITIAL_COINS, "last_daily": None}
        entry["username"] = username
        entry["coins"] = max(0, int(entry["coins"]) + delta)
        state["coins"][user_id] = entry
        _save(state)
        return entry["coins"]


def claim_daily(user_id: str, username: str) -> tuple[bool, int]:
    with _LOCK:
        state = _load()
        entry = state["coins"].get(user_id)
        if entry is None:
            entry = {"username": username, "coins": _INITIAL_COINS, "last_daily": None}
        today = date.today().isoformat()
        if entry.get("last_daily") == today:
            return False, int(entry["coins"])
        entry["username"] = username
        entry["coins"] = int(entry["coins"]) + _DAILY_AMOUNT
        entry["last_daily"] = today
        state["coins"][user_id] = entry
        _save(state)
        return True, entry["coins"]


def get_top_coins(limit: int = 10) -> list[dict[str, Any]]:
    with _LOCK:
        coins = _load().get("coins", {})
        entries = [
            {
                "user_id": user_id,
                "username": str(entry.get("username") or user_id),
                "coins": int(entry.get("coins", 0)),
            }
            for user_id, entry in coins.items()
            if isinstance(entry, dict)
        ]

    entries.sort(key=lambda entry: (-entry["coins"], entry["username"].casefold()))
    return entries[:max(1, int(limit))]


# ---------------------------------------------------------------------------
# Favorites
# ---------------------------------------------------------------------------

def add_favorite(user_id: str, username: str, track: dict[str, Any]) -> tuple[bool, dict[str, Any]]:
    with _LOCK:
        state = _load()
        entry = state["favorites"].get(user_id)
        if entry is None:
            entry = {"username": username, "tracks": []}
        entry["username"] = username

        already = any(t.get("title") == track.get("title") for t in entry["tracks"])
        if already:
            state["favorites"][user_id] = entry
            _save(state)
            return False, entry

        stored_track = {
            "title": track.get("title", ""),
            "query": track.get("query") or track.get("title", ""),
            # Direct stream URLs from YouTube expire after a few hours, so we
            # never persist them — only the stable title/query to re-search.
            "url": "",
            "duration_seconds": int(track.get("duration_seconds") or 210),
        }
        entry["tracks"].append(stored_track)
        state["favorites"][user_id] = entry

        state["radio_extra"] = [t for t in state["radio_extra"] if t.get("title") != stored_track["title"]]
        state["radio_extra"].append(stored_track)

        _save(state)
        return True, entry


def get_admin_favorites() -> list[dict[str, Any]]:
    with _LOCK:
        return list(_load().get("radio_extra", []))
