# Highrise Music Bot — Linux/Pterodactyl setup

This archive contains the bot, radio server, and Turkish/English word game.
It does not contain bot tokens or saved room/user state.

## Requirements

- Linux server or Pterodactyl Python 3.11 runtime
- `ffmpeg` available on the server for audio playback
- Writable persistent storage for the `storage/` directory
- Three Highrise bot tokens and their room IDs to run all three bots

## Install

Install Python dependencies from the project root:

```sh
python3.11 -m pip install -r requirements.txt
```

Copy `.env.example` to `.env` on the server and fill in the three token values.
The room IDs are already listed in their matching bot slots. Keep `.env` on the
server only; it is intentionally excluded from the archive.

Alternatively, set the same variable names in the server's environment settings.
The process reads values from the environment and uses `.env` only as a local
server-side option.

## Start

Use this command from the project root:

```sh
bash start.sh
```

The launcher loads `.env` when present, then starts three isolated bot
processes. To run just the first bot, set `HIGHRISE_TOKEN` and
`HIGHRISE_ROOM_ID`, then use `python3.11 main.py`.

The three-bot setup uses ports 9000, 9001, and 9002 by default. Open or route
all three ports for radio streams. Set `RADIO_PUBLIC_URL` to the server's
public HTTPS address for links that listeners can open.

## Keep the server running

Configure the host's process manager or Pterodactyl startup command to run
`bash start.sh` from the extracted project root. Keep `storage/` on persistent
disk so room settings and other bot state survive restarts.

## Environment variables

- `HIGHRISE_TOKEN`, `HIGHRISE_ROOM_ID`
- `HIGHRISE_TOKEN_2`, `HIGHRISE_ROOM_ID_2`
- `HIGHRISE_TOKEN_3`, `HIGHRISE_ROOM_ID_3`
- `RADIO_PUBLIC_URL`
- Optional: `MAIN_BOT_PORT`, `BOT_2_PORT`, `BOT_3_PORT`

Do not paste tokens into chat, source files, or ZIP archives. Rotate any token
that has been exposed before using the server.
