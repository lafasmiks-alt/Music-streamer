#!/usr/bin/env bash

set -u

cd "$(dirname "$0")"

PYTHON_BIN="${PYTHON_BIN:-python3}"
MAIN_BOT_PORT="${MAIN_BOT_PORT:-${PORT:-${SERVER_PORT:-9000}}}"
BOT_2_PORT="${BOT_2_PORT:-9001}"
BOT_3_PORT="${BOT_3_PORT:-9002}"

required_vars=(
  HIGHRISE_TOKEN
  HIGHRISE_ROOM_ID
  HIGHRISE_TOKEN_2
  HIGHRISE_ROOM_ID_2
  HIGHRISE_TOKEN_3
  HIGHRISE_ROOM_ID_3
)

missing_vars=()
for variable in "${required_vars[@]}"; do
  if [[ -z "${!variable:-}" ]]; then
    missing_vars+=("${variable}")
  fi
done

if ((${#missing_vars[@]})); then
  printf '[Bot] Missing required environment variables: %s\n' "${missing_vars[*]}" >&2
  echo "[Bot] Set them in the server environment or create a server-side .env file." >&2
  exit 1
fi

children=()

cleanup() {
  trap - INT TERM EXIT
  for child in "${children[@]}"; do
    kill "${child}" 2>/dev/null || true
  done
  wait 2>/dev/null || true
}

trap cleanup INT TERM EXIT

run_bot() {
  local instance="$1"
  local port="$2"
  local state_file="$3"
  local token_var="$4"
  local room_var="$5"
  local stream_path="$6"

  while true; do
    echo "[Bot ${instance}] Starting on port ${port}..."
    BOT_INSTANCE="${instance}" \
    PORT="${port}" \
    HIGHRISE_TOKEN="${!token_var}" \
    HIGHRISE_ROOM_ID="${!room_var}" \
    BOT_STATE_FILE="${state_file}" \
    RADIO_STREAM_PATH="${stream_path}" \
    "${PYTHON_BIN}" -u main.py
    exit_code=$?
    echo "[Bot ${instance}] Process exited with code ${exit_code}, restarting in 3s..."
    sleep 3
  done
}

run_bot "1" "${MAIN_BOT_PORT}" "storage/state.json" "HIGHRISE_TOKEN" "HIGHRISE_ROOM_ID" "/api/radio/stream" &
children+=("$!")
run_bot "2" "${BOT_2_PORT}" "storage/state-bot2.json" "HIGHRISE_TOKEN_2" "HIGHRISE_ROOM_ID_2" "/api/radio/stream/2" &
children+=("$!")
run_bot "3" "${BOT_3_PORT}" "storage/state-bot3.json" "HIGHRISE_TOKEN_3" "HIGHRISE_ROOM_ID_3" "/api/radio/stream/3" &
children+=("$!")

wait