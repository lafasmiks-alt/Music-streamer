#!/usr/bin/env bash

set -euo pipefail
cd "$(dirname "$0")"

if [[ -f ".env" ]]; then
  set -a
  # .env is created and maintained on the server, never included in the ZIP.
  source ./.env
  set +a
fi

exec bash ./run_all_bots.sh
