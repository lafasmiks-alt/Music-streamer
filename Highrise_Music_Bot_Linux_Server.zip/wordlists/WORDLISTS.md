# Word list and clue sources

The game has exactly 20,000 Turkish words and 20,000 English words. Each list
has a matching semantic clue file. A small curated set uses hand-written clues.

## Turkish words and clues

- Source: Turkish-language Wiktionary, extracted and structured by Wiktextract/Kaikki.
- Dataset: https://kaikki.org/trwiktionary/
- Raw-data description and license: https://kaikki.org/trwiktionary/rawdata.html
- The source states that Wiktionary data is available under CC BY-SA and GFDL.
- Changes: filtered to Turkish alphabetic entries, excluded marked inflections and
  proper names, selected 20,000 entries, shortened definitions, and removed any
  definition that directly repeats its answer.

Redistributed Turkish word and clue data must retain Wiktionary/Kaikki
attribution and comply with the source licenses.

## English words and clues

- Source: Open English WordNet 2025.
- Source URL: https://github.com/globalwordnet/english-wordnet
- License: Creative Commons Attribution 4.0 International (CC BY 4.0).
- License URL: https://creativecommons.org/licenses/by/4.0/
- Changes: selected 20,000 alphabetic entries, shortened definitions, and
  removed any definition that directly repeats its answer.

Redistributed English word and clue data must retain the source attribution and
license notice.

The runtime uses one clue per round. If a selected word has no usable dictionary
definition, the bot falls back to a clue based on the word length and its first
and last letters.

For Botkeep uploads, the hint dictionaries are split into smaller JSON chunks
below the hosting platform's per-file size limit. The bot merges these chunks
at startup; the word and clue entries are unchanged.
