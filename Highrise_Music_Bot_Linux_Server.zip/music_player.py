"""SoundCloud search + audio resolution for the radio, backed by yt-dlp."""

from __future__ import annotations

import asyncio
import re
import time
import unicodedata
from dataclasses import dataclass
from difflib import SequenceMatcher
from typing import AsyncIterator, Optional

import yt_dlp

_SEARCH_OPTS = {
    "format": "bestaudio/best",
    "noplaylist": True,
    "quiet": True,
    "no_warnings": True,
    # YouTube now blocks yt-dlp searches with a "sign in to confirm you're
    # not a bot" wall that requires real browser cookies to bypass. SoundCloud
    # search works without any auth, so it's the default for plain-text
    # queries. Direct http(s) links (YouTube or otherwise) are still passed
    # straight through in _search_sync/_resolve_sync below.
    "default_search": "scsearch5",
    "skip_download": True,
    "extract_flat": True,
    "socket_timeout": 8,
}
_RESOLVE_OPTS = {**_SEARCH_OPTS, "extract_flat": False}

# Transient network/YouTube hiccups (timeouts, rate limits, temporary
# extraction errors) should be retried a couple of times before we tell the
# user "şarkı bulunamadı" — otherwise a one-off blip looks like a permanent
# failure.
_MAX_ATTEMPTS = 2
_RETRY_DELAY_SECONDS = 0.5
_MAX_ALTERNATIVES = 4
_SEARCH_STOP_WORDS = {
    "a", "an", "and", "audio", "hd", "lyrics", "lyric", "music", "official",
    "the", "topic", "video", "vevo", "4k",
}
_VARIANT_MARKERS = {
    "acoustic", "bootleg", "cover", "edit", "flip", "instrumental", "karaoke",
    "live", "mashup", "nightcore", "remake", "remix", "rework", "slowed",
    "sped", "version",
}


def _search_tokens(value: str) -> list[str]:
    value = value.casefold().replace("ı", "i")
    normalized = unicodedata.normalize("NFKD", value)
    ascii_text = "".join(character for character in normalized if not unicodedata.combining(character))
    return re.findall(r"[a-z0-9]+", ascii_text)


def _search_score(query: str, title: str) -> float:
    query_tokens = _search_tokens(query)
    title_tokens = _search_tokens(title)
    query_terms = [token for token in query_tokens if token not in _SEARCH_STOP_WORDS]
    if not query_terms:
        query_terms = query_tokens
    if not query_terms or not title_tokens:
        return 0.0

    query_set = set(query_terms)
    title_set = set(title_tokens)
    overlap = len(query_set & title_set) / len(query_set)
    sequence = SequenceMatcher(
        None,
        " ".join(query_terms),
        " ".join(token for token in title_tokens if token not in _SEARCH_STOP_WORDS),
    ).ratio()
    score = (0.72 * overlap) + (0.28 * sequence)

    unexpected_variants = (_VARIANT_MARKERS & title_set) - query_set
    score -= min(0.65, 0.45 * len(unexpected_variants))
    return max(0.0, min(score, 1.0))


@dataclass
class Track:
    title: str
    url: str  # stable source page URL (not an ephemeral direct stream link)
    duration_seconds: int
    requested_by: Optional[str] = None
    requested_by_id: Optional[str] = None
    coins_charged: int = 0
    alternatives: tuple[str, ...] = ()

    @property
    def duration_str(self) -> str:
        seconds = max(0, int(self.duration_seconds))
        minutes, secs = divmod(seconds, 60)
        return f"{minutes}:{secs:02d}"


class MusicPlayer:
    """Resolves search queries / links to playable tracks via yt-dlp."""

    async def search(self, query: str) -> Optional[Track]:
        loop = asyncio.get_running_loop()
        return await loop.run_in_executor(None, self._search_sync, query)

    def _search_sync(self, query: str) -> Optional[Track]:
        is_direct_url = query.startswith("http://") or query.startswith("https://")
        search_queries = [query]
        if not is_direct_url:
            cleaned = re.sub(
                r"\b(?:official(?:\s+(?:audio|video))?|music\s+video|lyrics?|vevo|topic)\b",
                " ",
                query,
                flags=re.IGNORECASE,
            )
            cleaned = " ".join(cleaned.split())
            variants = [
                cleaned,
                cleaned.casefold().replace("ı", "i"),
                unicodedata.normalize("NFKD", cleaned)
                .encode("ascii", "ignore")
                .decode("ascii"),
            ]
            search_queries = []
            seen_queries: set[str] = set()
            for variant in variants:
                variant = " ".join(variant.split())
                key = variant.casefold()
                if variant and key not in seen_queries:
                    search_queries.append(variant)
                    seen_queries.add(key)

        entries_by_url: dict[str, tuple[float, dict]] = {}
        last_error: Optional[Exception] = None

        targets = [query] if is_direct_url else [f"scsearch5:{item}" for item in search_queries]
        for target in targets:
            info = None
            options = _RESOLVE_OPTS if is_direct_url else _SEARCH_OPTS
            for attempt in range(1, _MAX_ATTEMPTS + 1):
                try:
                    with yt_dlp.YoutubeDL(options) as ydl:
                        info = ydl.extract_info(target, download=False)
                    last_error = None
                    break
                except Exception as e:
                    last_error = e
                    print(f"[MusicPlayer] Arama hatası ({query!r}), deneme {attempt}/{_MAX_ATTEMPTS}: {e}")
                    if attempt < _MAX_ATTEMPTS:
                        time.sleep(_RETRY_DELAY_SECONDS)

            if not info:
                continue
            results = [entry for entry in info.get("entries", []) if entry] if "entries" in info else [info]
            for entry in results:
                webpage_url = entry.get("webpage_url") or entry.get("original_url")
                title = entry.get("title")
                if not webpage_url or not title:
                    continue
                score = _search_score(query, title)
                previous = entries_by_url.get(webpage_url)
                if previous is None or score > previous[0]:
                    entries_by_url[webpage_url] = (score, entry)

            if is_direct_url or (entries_by_url and max(score for score, _ in entries_by_url.values()) >= 0.9):
                break

        if not entries_by_url:
            if last_error is None:
                print(f"[MusicPlayer] SoundCloud'da eşleşme bulunamadı: {query!r}")
            return None

        ranked_entries = sorted(
            entries_by_url.items(),
            key=lambda item: item[1][0],
            reverse=True,
        )
        best_score = ranked_entries[0][1][0]
        if best_score < 0.16 and not is_direct_url:
            print(f"[MusicPlayer] Eşleşme zayıf olduğu için reddedildi: {query!r}")
            return None

        webpage_url, (_, first) = ranked_entries[0]
        title = first.get("title") or query
        duration = int(first.get("duration") or 210)

        alternatives: list[str] = []
        for candidate_url, _ in ranked_entries[1:]:
            alternatives.append(candidate_url)
            if len(alternatives) >= _MAX_ALTERNATIVES:
                break

        return Track(
            title=title,
            url=webpage_url,
            duration_seconds=duration,
            alternatives=tuple(alternatives),
        )

    async def resolve_stream_url(self, track: Track) -> Optional[str]:
        """Resolve a fresh direct audio URL for `track` (expires after a few hours)."""
        async for stream_url in self.iter_stream_urls(track):
            return stream_url
        return None

    async def iter_stream_urls(self, track: Track) -> AsyncIterator[str]:
        """Resolve one source at a time so playback starts before fallbacks."""
        loop = asyncio.get_running_loop()
        seen: set[str] = set()
        for candidate in (track.url, *track.alternatives):
            stream_url = await loop.run_in_executor(None, self._resolve_sync, candidate)
            if stream_url and stream_url not in seen:
                seen.add(stream_url)
                yield stream_url

    async def resolve_stream_urls(self, track: Track) -> list[str]:
        """Resolve fresh URLs for the track and its search alternatives.

        SoundCloud can return a track whose media is DRM-protected or whose
        CDN URL has just expired. Returning all candidates lets the playback
        loop try another result instead of silently skipping the request.
        """
        loop = asyncio.get_running_loop()
        return await loop.run_in_executor(None, self._resolve_sync_candidates, track)

    def _resolve_sync_candidates(self, track: Track) -> list[str]:
        resolved: list[str] = []
        for candidate in (track.url, *track.alternatives):
            stream_url = self._resolve_sync(candidate)
            if stream_url and stream_url not in resolved:
                resolved.append(stream_url)
        return resolved

    def _resolve_sync(self, video_url: str) -> Optional[str]:
        info = None

        for attempt in range(1, _MAX_ATTEMPTS + 1):
            try:
                with yt_dlp.YoutubeDL(_RESOLVE_OPTS) as ydl:
                    info = ydl.extract_info(video_url, download=False)
                break
            except Exception as e:
                print(f"[MusicPlayer] Ses linki çözülemedi ({video_url!r}), deneme {attempt}/{_MAX_ATTEMPTS}: {e}")
                if attempt < _MAX_ATTEMPTS:
                    time.sleep(_RETRY_DELAY_SECONDS)

        if not info:
            return None
        if "entries" in info:
            entries = [e for e in info["entries"] if e]
            if not entries:
                return None
            info = entries[0]
        return info.get("url")
