"""Live audio broadcaster: transcodes whatever track is 'now playing' to mp3
and fans it out to every connected HTTP listener, like a real radio station.

Point the room's Highrise radio/boombox settings at GET /api/radio/stream.
"""

from __future__ import annotations

import asyncio
import contextlib
from pathlib import Path
from typing import Optional

from aiohttp import ClientSession, web


_WEB_ROOT = Path(__file__).resolve().parents[2] / "artifacts" / "highrise-bot" / "dist" / "public"


class AudioBroadcaster:
    def __init__(self) -> None:
        self._subscribers: set[asyncio.Queue] = set()
        self._current_process: Optional[asyncio.subprocess.Process] = None
        self._last_audio_bytes = 0

    def subscribe(self) -> asyncio.Queue:
        q: asyncio.Queue = asyncio.Queue(maxsize=64)
        self._subscribers.add(q)
        return q

    def unsubscribe(self, q: asyncio.Queue) -> None:
        self._subscribers.discard(q)

    def listener_count(self) -> int:
        return len(self._subscribers)

    def is_playing(self) -> bool:
        return self._current_process is not None

    def _broadcast(self, chunk: bytes) -> None:
        dead = []
        for q in self._subscribers:
            try:
                q.put_nowait(chunk)
            except asyncio.QueueFull:
                # Listener is falling behind — drop its oldest buffered chunk
                # so it stays close to live instead of building up latency.
                try:
                    q.get_nowait()
                    q.put_nowait(chunk)
                except Exception:
                    dead.append(q)
        for q in dead:
            self._subscribers.discard(q)

    async def play_url(self, stream_url: str) -> bool:
        """Transcode `stream_url` to mp3 in real time and broadcast it.

        Blocks until playback finishes naturally or this coroutine is
        cancelled (used by !skip / !stop). Returns whether ffmpeg produced
        audio bytes, so callers can try another source when a CDN result is
        unusable.
        """
        cmd = [
            "ffmpeg",
            "-hide_banner",
            "-loglevel", "error",
            "-nostdin",
            "-re",
            "-i", stream_url,
            "-vn",
            "-acodec", "libmp3lame",
            "-b:a", "128k",
            "-ar", "44100",
            "-ac", "2",
            "-f", "mp3",
            "-",
        ]
        proc = await asyncio.create_subprocess_exec(
            *cmd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        self._current_process = proc
        stderr_task: Optional[asyncio.Task] = None
        produced_audio = False
        try:
            assert proc.stdout is not None
            assert proc.stderr is not None
            stderr_task = asyncio.create_task(proc.stderr.read())
            while True:
                chunk = await proc.stdout.read(8192)
                if not chunk:
                    break
                produced_audio = True
                self._last_audio_bytes += len(chunk)
                self._broadcast(chunk)
            await proc.wait()
            stderr_output = await stderr_task
            if proc.returncode != 0 or not produced_audio:
                detail = stderr_output.decode("utf-8", errors="replace").strip()
                if len(detail) > 500:
                    detail = detail[-500:]
                print(
                    f"[Radio] ffmpeg başarısız (exit={proc.returncode}, "
                    f"audio_bytes={self._last_audio_bytes}): {detail or 'ses verisi üretilmedi'}"
                )
            return produced_audio
        except asyncio.CancelledError:
            if stderr_task and not stderr_task.done():
                stderr_task.cancel()
            raise
        finally:
            if proc.returncode is None:
                with contextlib.suppress(ProcessLookupError):
                    proc.kill()
                with contextlib.suppress(Exception):
                    await proc.wait()
            if stderr_task and not stderr_task.done():
                stderr_task.cancel()
            if self._current_process is proc:
                self._current_process = None


async def _stream_handler(request: web.Request) -> web.StreamResponse:
    broadcaster: AudioBroadcaster = request.app["broadcaster"]
    resp = web.StreamResponse(
        status=200,
        reason="OK",
        headers={
            "Content-Type": "audio/mpeg",
            "Cache-Control": "no-cache, no-store, must-revalidate",
            "Connection": "keep-alive",
            "icy-name": "Highrise Radyo",
        },
    )
    await resp.prepare(request)
    q = broadcaster.subscribe()
    try:
        while True:
            chunk = await q.get()
            await resp.write(chunk)
    except (asyncio.CancelledError, ConnectionResetError):
        pass
    finally:
        broadcaster.unsubscribe(q)
    return resp


async def _health_handler(request: web.Request) -> web.Response:
    broadcaster: AudioBroadcaster = request.app["broadcaster"]
    return web.json_response({
        "ok": True,
        "listeners": broadcaster.listener_count(),
        "playing": broadcaster.is_playing(),
    })


async def _fallback_root_handler(request: web.Request) -> web.Response:
    return web.json_response({
        "ok": True,
        "service": "Highrise Music Bot",
        "message": "Bot is running.",
    })


async def _proxy_bot_stream(request: web.Request) -> web.StreamResponse:
    bot_number = request.match_info["bot_number"]
    target_port = {"2": 9001, "3": 9002}.get(bot_number)
    if target_port is None:
        return web.json_response({"ok": False, "error": "Unknown bot"}, status=404)

    try:
        async with ClientSession() as session:
            async with session.get(
                f"http://127.0.0.1:{target_port}/api/radio/stream",
                headers={"Accept": "audio/mpeg"},
            ) as upstream:
                response = web.StreamResponse(
                    status=upstream.status,
                    headers={
                        "Content-Type": upstream.headers.get("Content-Type", "audio/mpeg"),
                        "Cache-Control": "no-cache, no-store, must-revalidate",
                        "Connection": "keep-alive",
                    },
                )
                await response.prepare(request)
                async for chunk in upstream.content.iter_chunked(8192):
                    await response.write(chunk)
                return response
    except (asyncio.CancelledError, ConnectionResetError):
        raise
    except Exception as exc:
        return web.json_response({"ok": False, "error": str(exc)}, status=502)


async def _proxy_bot_health(request: web.Request) -> web.Response:
    bot_number = request.match_info["bot_number"]
    target_port = {"2": 9001, "3": 9002}.get(bot_number)
    if target_port is None:
        return web.json_response({"ok": False, "error": "Unknown bot"}, status=404)

    try:
        async with ClientSession() as session:
            async with session.get(f"http://127.0.0.1:{target_port}/api/radio/health") as upstream:
                payload = await upstream.json()
                return web.json_response(payload, status=upstream.status)
    except Exception as exc:
        return web.json_response({"ok": False, "error": str(exc)}, status=502)


def create_app(broadcaster: AudioBroadcaster) -> web.Application:
    app = web.Application()
    app["broadcaster"] = broadcaster
    app.router.add_get("/api/radio/stream", _stream_handler)
    app.router.add_get("/api/radio/health", _health_handler)
    app.router.add_get("/api/radio/stream/{bot_number:2|3}", _proxy_bot_stream)
    app.router.add_get("/api/radio/health/{bot_number:2|3}", _proxy_bot_health)
    app.router.add_get("/health", _health_handler)
    if (_WEB_ROOT / "index.html").is_file():
        app.router.add_static("/", _WEB_ROOT, show_index=True)
    else:
        app.router.add_get("/", _fallback_root_handler)
    return app
