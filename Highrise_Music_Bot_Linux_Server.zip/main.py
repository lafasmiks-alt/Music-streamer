"""Entrypoint: runs the radio HTTP stream server and the Highrise bot
in the same asyncio event loop so they can share in-memory state.
"""

from __future__ import annotations

import asyncio
import os

from aiohttp import web
from highrise.__main__ import BotDefinition, main as highrise_main

import data
from music_bot import MusicBot
from radio import AudioBroadcaster, create_app


async def run() -> None:
    token = os.environ["HIGHRISE_TOKEN"]
    configured_room_id = data.get_current_room_id() or os.environ.get("HIGHRISE_ROOM_ID")
    room_id = configured_room_id
    if not room_id:
        raise SystemExit("HIGHRISE_ROOM_ID env var (or a saved room id) is required.")

    port = int(os.environ.get("PORT") or os.environ.get("SERVER_PORT") or "8080")
    public_url = os.environ.get("RADIO_PUBLIC_URL", "").rstrip("/")
    if not public_url:
        domain = os.environ.get("REPLIT_DEPLOYMENT_URL", "") or os.environ.get("REPLIT_DEV_DOMAIN", "")
        if domain:
            public_url = domain if domain.startswith(("http://", "https://")) else f"https://{domain}"

    if public_url:
        stream_path = os.environ.get("RADIO_STREAM_PATH", "/api/radio/stream")
        stream_url = f"{public_url}{stream_path}"
        os.environ["RADIO_STREAM_URL"] = stream_url
        print(f"[Radio] Yayın URL: {stream_url}")
    else:
        print("[Radio] Genel yayın adresi bulunamadı. RADIO_PUBLIC_URL ayarlanırsa !url çalışır.")

    broadcaster = AudioBroadcaster()

    app = create_app(broadcaster)
    runner = web.AppRunner(app)
    await runner.setup()
    site = web.TCPSite(runner, "0.0.0.0", port)
    await site.start()
    print(f"[Radio] Yayın sunucusu 0.0.0.0:{port} üzerinde çalışıyor.")

    while True:
        bot = MusicBot(broadcaster, room_id=room_id)
        print(f"[Bot] Odaya bağlanılıyor: {room_id}")
        try:
            await highrise_main([BotDefinition(bot, room_id, token)])
            print("[Bot] Highrise bağlantısı sonlandı; 3 saniye sonra yeniden bağlanılacak.")
        except SystemExit as e:
            # !restart and !room intentionally use sys.exit(). Keep the
            # process alive so the supervisor can reconnect without losing
            # the radio server or the selected room.
            print(f"[Bot] Kontrollü yeniden başlatma (kod={e.code}); 3 saniye sonra bağlanılacak.")
        except Exception as e:
            last_good = data.get_last_good_room_id()
            if last_good and last_good != room_id:
                print(
                    f"[Bot] Odaya bağlanılamadı ({room_id}): {e}. "
                    f"Son çalışan odaya geri dönülüyor: {last_good}"
                )
                data.save_room_id(last_good)
                room_id = last_good
            else:
                print(f"[Bot] Odaya bağlanılamadı ({room_id}): {e}. Yeniden denenecek.")

        # !room writes the new room before requesting a restart. Always
        # re-read it so a controlled restart uses the new room immediately.
        room_id = data.get_current_room_id() or room_id or configured_room_id
        await asyncio.sleep(3)


if __name__ == "__main__":
    asyncio.run(run())
